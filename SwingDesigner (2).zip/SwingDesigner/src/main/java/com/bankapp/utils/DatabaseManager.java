package com.bankapp.utils;

import com.bankapp.model.*;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Database manager class for handling persistence of application data
 * Implements the Singleton design pattern to ensure a single instance
 */
public class DatabaseManager {
    private static DatabaseManager instance;
    
    // Data store maps
    private Map<String, User> users;
    private Map<String, Account> accounts;
    private Map<String, Transaction> transactions;
    private Map<String, WithdrawalRequest> withdrawalRequests;
    
    // File paths for persistence
    private static final String DATA_DIR = "data";
    private static final String USERS_FILE = DATA_DIR + File.separator + "users.dat";
    private static final String ACCOUNTS_FILE = DATA_DIR + File.separator + "accounts.dat";
    private static final String TRANSACTIONS_FILE = DATA_DIR + File.separator + "transactions.dat";
    private static final String WITHDRAWAL_REQUESTS_FILE = DATA_DIR + File.separator + "withdrawal_requests.dat";
    
    // Thread safety
    private final ReadWriteLock usersLock = new ReentrantReadWriteLock();
    private final ReadWriteLock accountsLock = new ReentrantReadWriteLock();
    private final ReadWriteLock transactionsLock = new ReentrantReadWriteLock();
    private final ReadWriteLock withdrawalRequestsLock = new ReentrantReadWriteLock();
    
    // Private constructor for singleton
    private DatabaseManager() {
        users = new HashMap<>();
        accounts = new HashMap<>();
        transactions = new HashMap<>();
        withdrawalRequests = new HashMap<>();
    }
    
    /**
     * Get the singleton instance of the DatabaseManager
     * 
     * @return The DatabaseManager instance
     */
    public static synchronized DatabaseManager getInstance() {
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }
    
    /**
     * Initialize the database manager
     * Creates data directory and loads data from files
     */
    public void initialize() {
        // Create data directory if it doesn't exist
        File dataDir = new File(DATA_DIR);
        if (!dataDir.exists()) {
            dataDir.mkdirs();
        }
        
        // Load data from files
        loadData();
    }
    
    /**
     * Load all data from files
     */
    @SuppressWarnings("unchecked")
    private void loadData() {
        // Load users
        try {
            File usersFile = new File(USERS_FILE);
            if (usersFile.exists()) {
                try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(usersFile))) {
                    usersLock.writeLock().lock();
                    try {
                        users = (Map<String, User>) ois.readObject();
                    } finally {
                        usersLock.writeLock().unlock();
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading users: " + e.getMessage());
            e.printStackTrace();
        }
        
        // Load accounts
        try {
            File accountsFile = new File(ACCOUNTS_FILE);
            if (accountsFile.exists()) {
                try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(accountsFile))) {
                    accountsLock.writeLock().lock();
                    try {
                        accounts = (Map<String, Account>) ois.readObject();
                    } finally {
                        accountsLock.writeLock().unlock();
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading accounts: " + e.getMessage());
            e.printStackTrace();
        }
        
        // Load transactions
        try {
            File transactionsFile = new File(TRANSACTIONS_FILE);
            if (transactionsFile.exists()) {
                try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(transactionsFile))) {
                    transactionsLock.writeLock().lock();
                    try {
                        transactions = (Map<String, Transaction>) ois.readObject();
                    } finally {
                        transactionsLock.writeLock().unlock();
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading transactions: " + e.getMessage());
            e.printStackTrace();
        }
        
        // Load withdrawal requests
        try {
            File withdrawalRequestsFile = new File(WITHDRAWAL_REQUESTS_FILE);
            if (withdrawalRequestsFile.exists()) {
                try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(withdrawalRequestsFile))) {
                    withdrawalRequestsLock.writeLock().lock();
                    try {
                        withdrawalRequests = (Map<String, WithdrawalRequest>) ois.readObject();
                    } finally {
                        withdrawalRequestsLock.writeLock().unlock();
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading withdrawal requests: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Save all data to files
     */
    private void saveData() {
        // Save users
        try {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(USERS_FILE))) {
                usersLock.readLock().lock();
                try {
                    oos.writeObject(users);
                } finally {
                    usersLock.readLock().unlock();
                }
            }
        } catch (Exception e) {
            System.err.println("Error saving users: " + e.getMessage());
            e.printStackTrace();
        }
        
        // Save accounts
        try {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ACCOUNTS_FILE))) {
                accountsLock.readLock().lock();
                try {
                    oos.writeObject(accounts);
                } finally {
                    accountsLock.readLock().unlock();
                }
            }
        } catch (Exception e) {
            System.err.println("Error saving accounts: " + e.getMessage());
            e.printStackTrace();
        }
        
        // Save transactions
        try {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(TRANSACTIONS_FILE))) {
                transactionsLock.readLock().lock();
                try {
                    oos.writeObject(transactions);
                } finally {
                    transactionsLock.readLock().unlock();
                }
            }
        } catch (Exception e) {
            System.err.println("Error saving transactions: " + e.getMessage());
            e.printStackTrace();
        }
        
        // Save withdrawal requests
        try {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(WITHDRAWAL_REQUESTS_FILE))) {
                withdrawalRequestsLock.readLock().lock();
                try {
                    oos.writeObject(withdrawalRequests);
                } finally {
                    withdrawalRequestsLock.readLock().unlock();
                }
            }
        } catch (Exception e) {
            System.err.println("Error saving withdrawal requests: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Get a user by ID
     * 
     * @param userId The user ID
     * @return The user, or null if not found
     */
    public User getUser(String userId) {
        usersLock.readLock().lock();
        try {
            return users.get(userId);
        } finally {
            usersLock.readLock().unlock();
        }
    }
    
    /**
     * Get all users
     * 
     * @return Map of all users
     */
    public Map<String, User> getAllUsers() {
        usersLock.readLock().lock();
        try {
            return new HashMap<>(users);
        } finally {
            usersLock.readLock().unlock();
        }
    }
    
    /**
     * Save a user
     * 
     * @param user The user to save
     * @return true if the save was successful, false otherwise
     */
    public boolean saveUser(User user) {
        if (user == null || user.getUserId() == null) {
            return false;
        }
        
        usersLock.writeLock().lock();
        try {
            users.put(user.getUserId(), user);
            saveData();
            return true;
        } catch (Exception e) {
            System.err.println("Error saving user: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            usersLock.writeLock().unlock();
        }
    }
    
    /**
     * Delete a user
     * 
     * @param userId The ID of the user to delete
     * @return true if the deletion was successful, false otherwise
     */
    public boolean deleteUser(String userId) {
        if (userId == null) {
            return false;
        }
        
        usersLock.writeLock().lock();
        try {
            if (users.containsKey(userId)) {
                users.remove(userId);
                saveData();
                return true;
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error deleting user: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            usersLock.writeLock().unlock();
        }
    }
    
    /**
     * Get an account by ID
     * 
     * @param accountId The account ID
     * @return The account, or null if not found
     */
    public Account getAccount(String accountId) {
        accountsLock.readLock().lock();
        try {
            return accounts.get(accountId);
        } finally {
            accountsLock.readLock().unlock();
        }
    }
    
    /**
     * Get all accounts
     * 
     * @return Map of all accounts
     */
    public Map<String, Account> getAllAccounts() {
        accountsLock.readLock().lock();
        try {
            return new HashMap<>(accounts);
        } finally {
            accountsLock.readLock().unlock();
        }
    }
    
    /**
     * Save an account
     * 
     * @param account The account to save
     * @return true if the save was successful, false otherwise
     */
    public boolean saveAccount(Account account) {
        if (account == null || account.getAccountId() == null) {
            return false;
        }
        
        accountsLock.writeLock().lock();
        try {
            accounts.put(account.getAccountId(), account);
            saveData();
            return true;
        } catch (Exception e) {
            System.err.println("Error saving account: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            accountsLock.writeLock().unlock();
        }
    }
    
    /**
     * Delete an account
     * 
     * @param accountId The ID of the account to delete
     * @return true if the deletion was successful, false otherwise
     */
    public boolean deleteAccount(String accountId) {
        if (accountId == null) {
            return false;
        }
        
        accountsLock.writeLock().lock();
        try {
            if (accounts.containsKey(accountId)) {
                accounts.remove(accountId);
                saveData();
                return true;
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error deleting account: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            accountsLock.writeLock().unlock();
        }
    }
    
    /**
     * Get a transaction by ID
     * 
     * @param transactionId The transaction ID
     * @return The transaction, or null if not found
     */
    public Transaction getTransaction(String transactionId) {
        transactionsLock.readLock().lock();
        try {
            return transactions.get(transactionId);
        } finally {
            transactionsLock.readLock().unlock();
        }
    }
    
    /**
     * Get all transactions
     * 
     * @return Map of all transactions
     */
    public Map<String, Transaction> getAllTransactions() {
        transactionsLock.readLock().lock();
        try {
            return new HashMap<>(transactions);
        } finally {
            transactionsLock.readLock().unlock();
        }
    }
    
    /**
     * Save a transaction
     * 
     * @param transaction The transaction to save
     * @return true if the save was successful, false otherwise
     */
    public boolean saveTransaction(Transaction transaction) {
        if (transaction == null || transaction.getTransactionId() == null) {
            return false;
        }
        
        transactionsLock.writeLock().lock();
        try {
            transactions.put(transaction.getTransactionId(), transaction);
            saveData();
            return true;
        } catch (Exception e) {
            System.err.println("Error saving transaction: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            transactionsLock.writeLock().unlock();
        }
    }
    
    /**
     * Delete a transaction
     * 
     * @param transactionId The ID of the transaction to delete
     * @return true if the deletion was successful, false otherwise
     */
    public boolean deleteTransaction(String transactionId) {
        if (transactionId == null) {
            return false;
        }
        
        transactionsLock.writeLock().lock();
        try {
            if (transactions.containsKey(transactionId)) {
                transactions.remove(transactionId);
                saveData();
                return true;
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error deleting transaction: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            transactionsLock.writeLock().unlock();
        }
    }
    
    /**
     * Get a withdrawal request by ID
     * 
     * @param requestId The request ID
     * @return The withdrawal request, or null if not found
     */
    public WithdrawalRequest getWithdrawalRequest(String requestId) {
        withdrawalRequestsLock.readLock().lock();
        try {
            return withdrawalRequests.get(requestId);
        } finally {
            withdrawalRequestsLock.readLock().unlock();
        }
    }
    
    /**
     * Get all withdrawal requests
     * 
     * @return Map of all withdrawal requests
     */
    public Map<String, WithdrawalRequest> getAllWithdrawalRequests() {
        withdrawalRequestsLock.readLock().lock();
        try {
            return new HashMap<>(withdrawalRequests);
        } finally {
            withdrawalRequestsLock.readLock().unlock();
        }
    }
    
    /**
     * Save a withdrawal request
     * 
     * @param request The withdrawal request to save
     * @return true if the save was successful, false otherwise
     */
    public boolean saveWithdrawalRequest(WithdrawalRequest request) {
        if (request == null || request.getRequestId() == null) {
            return false;
        }
        
        withdrawalRequestsLock.writeLock().lock();
        try {
            withdrawalRequests.put(request.getRequestId(), request);
            saveData();
            return true;
        } catch (Exception e) {
            System.err.println("Error saving withdrawal request: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            withdrawalRequestsLock.writeLock().unlock();
        }
    }
    
    /**
     * Delete a withdrawal request
     * 
     * @param requestId The ID of the withdrawal request to delete
     * @return true if the deletion was successful, false otherwise
     */
    public boolean deleteWithdrawalRequest(String requestId) {
        if (requestId == null) {
            return false;
        }
        
        withdrawalRequestsLock.writeLock().lock();
        try {
            if (withdrawalRequests.containsKey(requestId)) {
                withdrawalRequests.remove(requestId);
                saveData();
                return true;
            }
            return false;
        } catch (Exception e) {
            System.err.println("Error deleting withdrawal request: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            withdrawalRequestsLock.writeLock().unlock();
        }
    }
}
