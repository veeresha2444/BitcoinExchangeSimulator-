package com.bankapp.utils;

import java.math.BigDecimal;
import java.util.regex.Pattern;

/**
 * Utility class for validating input data
 */
public class ValidationUtils {
    // Regular expressions for validation
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_]{3,20}$");
    private static final Pattern PASSWORD_PATTERN = Pattern.compile("^.{6,}$");
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$");
    private static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z ,.'-]{2,50}$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\+?[0-9]{10,15}$");
    private static final Pattern AMOUNT_PATTERN = Pattern.compile("^\\d+(\\.\\d{1,2})?$");
    
    /**
     * Validate a username
     * 
     * @param username The username to validate
     * @return true if the username is valid, false otherwise
     */
    public static boolean isValidUsername(String username) {
        if (username == null) {
            return false;
        }
        return USERNAME_PATTERN.matcher(username).matches();
    }
    
    /**
     * Validate a password
     * 
     * @param password The password to validate
     * @return true if the password is valid, false otherwise
     */
    public static boolean isValidPassword(String password) {
        if (password == null) {
            return false;
        }
        return PASSWORD_PATTERN.matcher(password).matches();
    }
    
    /**
     * Validate an email address
     * 
     * @param email The email to validate
     * @return true if the email is valid, false otherwise
     */
    public static boolean isValidEmail(String email) {
        if (email == null) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email).matches();
    }
    
    /**
     * Validate a name
     * 
     * @param name The name to validate
     * @return true if the name is valid, false otherwise
     */
    public static boolean isValidName(String name) {
        if (name == null) {
            return false;
        }
        return NAME_PATTERN.matcher(name).matches();
    }
    
    /**
     * Validate a phone number
     * 
     * @param phone The phone number to validate
     * @return true if the phone number is valid, false otherwise
     */
    public static boolean isValidPhone(String phone) {
        if (phone == null) {
            return false;
        }
        return PHONE_PATTERN.matcher(phone).matches();
    }
    
    /**
     * Validate a monetary amount string
     * 
     * @param amount The amount to validate
     * @return true if the amount is a valid currency format, false otherwise
     */
    public static boolean isValidAmount(String amount) {
        if (amount == null) {
            return false;
        }
        return AMOUNT_PATTERN.matcher(amount).matches();
    }
    
    /**
     * Validate a BigDecimal amount
     * 
     * @param amount The amount to validate
     * @return true if the amount is valid (positive and has 2 or fewer decimal places), false otherwise
     */
    public static boolean isValidAmount(BigDecimal amount) {
        if (amount == null) {
            return false;
        }
        
        // Amount must be positive
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        
        // Check decimal places (should be 2 or fewer)
        String amountStr = amount.stripTrailingZeros().toPlainString();
        int decimalIndex = amountStr.indexOf('.');
        if (decimalIndex != -1) {
            int decimalPlaces = amountStr.length() - decimalIndex - 1;
            if (decimalPlaces > 2) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Validate an account number
     * 
     * @param accountNumber The account number to validate
     * @return true if the account number is valid, false otherwise
     */
    public static boolean isValidAccountNumber(String accountNumber) {
        if (accountNumber == null) {
            return false;
        }
        // Account number should be 10 digits
        return accountNumber.matches("^\\d{10}$");
    }
    
    /**
     * Sanitize input to prevent XSS and injection attacks
     * 
     * @param input The input to sanitize
     * @return The sanitized input
     */
    public static String sanitizeInput(String input) {
        if (input == null) {
            return "";
        }
        // Replace potentially dangerous characters
        return input.replaceAll("<", "&lt;")
                   .replaceAll(">", "&gt;")
                   .replaceAll("\"", "&quot;")
                   .replaceAll("'", "&#39;")
                   .replaceAll("&", "&amp;");
    }
}
