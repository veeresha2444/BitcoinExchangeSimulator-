package com.bankapp.utils;

import com.bankapp.model.User;

/**
 * Session manager for tracking the current authenticated user
 * Implements the Singleton design pattern to ensure a single instance
 */
public class SessionManager {
    private static SessionManager instance;
    private User currentUser;
    
    /**
     * Private constructor for singleton
     */
    private SessionManager() {
        this.currentUser = null;
    }
    
    /**
     * Get the singleton instance of the SessionManager
     * 
     * @return The SessionManager instance
     */
    public static synchronized SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }
    
    /**
     * Get the current authenticated user
     * 
     * @return The current user, or null if not authenticated
     */
    public User getCurrentUser() {
        return currentUser;
    }
    
    /**
     * Set the current authenticated user
     * 
     * @param user The user to set as the current user
     */
    public void setCurrentUser(User user) {
        this.currentUser = user;
    }
    
    /**
     * Clear the current session
     */
    public void clearSession() {
        this.currentUser = null;
    }
    
    /**
     * Check if a user is currently authenticated
     * 
     * @return true if a user is logged in, false otherwise
     */
    public boolean isAuthenticated() {
        return this.currentUser != null;
    }
    
    /**
     * Check if the current user has admin privileges
     * 
     * @return true if the current user is an admin, false otherwise
     */
    public boolean isAdmin() {
        return this.currentUser != null && this.currentUser.isAdmin();
    }
    
    /**
     * Get the current user's ID
     * 
     * @return The current user's ID, or null if not authenticated
     */
    public String getCurrentUserId() {
        return this.currentUser != null ? this.currentUser.getUserId() : null;
    }
}
