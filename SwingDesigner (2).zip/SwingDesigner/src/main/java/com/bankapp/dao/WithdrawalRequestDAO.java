package com.bankapp.dao;

import com.bankapp.model.WithdrawalRequest;
import com.bankapp.utils.DatabaseManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Data Access Object for WithdrawalRequest entities
 */
public class WithdrawalRequestDAO {
    private final DatabaseManager dbManager;
    
    public WithdrawalRequestDAO() {
        this.dbManager = DatabaseManager.getInstance();
    }
    
    /**
     * Find a withdrawal request by ID
     * 
     * @param requestId The request ID
     * @return The withdrawal request, or null if not found
     */
    public WithdrawalRequest findById(String requestId) {
        return dbManager.getWithdrawalRequest(requestId);
    }
    
    /**
     * Find pending withdrawal requests by user ID
     * 
     * @param userId The user ID
     * @return List of pending withdrawal requests for the user
     */
    public List<WithdrawalRequest> findPendingByUserId(String userId) {
        Map<String, WithdrawalRequest> requests = dbManager.getAllWithdrawalRequests();
        
        return requests.values().stream()
                .filter(request -> request.getUserId().equals(userId) && 
                        request.getStatus() == WithdrawalRequest.RequestStatus.PENDING)
                .collect(Collectors.toList());
    }
    
    /**
     * Find all pending withdrawal requests
     * 
     * @return List of all pending withdrawal requests
     */
    public List<WithdrawalRequest> findAllPending() {
        Map<String, WithdrawalRequest> requests = dbManager.getAllWithdrawalRequests();
        
        return requests.values().stream()
                .filter(request -> request.getStatus() == WithdrawalRequest.RequestStatus.PENDING)
                .collect(Collectors.toList());
    }
    
    /**
     * Get all withdrawal requests
     * 
     * @return List of all withdrawal requests
     */
    public List<WithdrawalRequest> findAll() {
        return new ArrayList<>(dbManager.getAllWithdrawalRequests().values());
    }
    
    /**
     * Save a new withdrawal request
     * 
     * @param request The withdrawal request to save
     * @return true if the save was successful, false otherwise
     */
    public boolean save(WithdrawalRequest request) {
        return dbManager.saveWithdrawalRequest(request);
    }
    
    /**
     * Update an existing withdrawal request
     * 
     * @param request The withdrawal request to update
     * @return true if the update was successful, false otherwise
     */
    public boolean update(WithdrawalRequest request) {
        // Check if the request exists
        if (findById(request.getRequestId()) == null) {
            return false;
        }
        
        // Save the updated request
        return dbManager.saveWithdrawalRequest(request);
    }
    
    /**
     * Delete a withdrawal request
     * 
     * @param requestId The ID of the withdrawal request to delete
     * @return true if the deletion was successful, false otherwise
     */
    public boolean delete(String requestId) {
        return dbManager.deleteWithdrawalRequest(requestId);
    }
}
