package com.bankapp.dao;

import com.bankapp.model.User;
import com.bankapp.utils.DatabaseManager;
import com.bankapp.utils.PasswordHasher;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Data Access Object for User entities
 */
public class UserDAO {
    private final DatabaseManager dbManager;
    
    public UserDAO() {
        this.dbManager = DatabaseManager.getInstance();
        
        // Create default admin user if it doesn't exist
        createDefaultAdminIfNotExists();
    }
    
    /**
     * Find a user by ID
     * 
     * @param userId The user ID
     * @return The user, or null if not found
     */
    public User findById(String userId) {
        return dbManager.getUser(userId);
    }
    
    /**
     * Find a user by username
     * 
     * @param username The username
     * @return The user, or null if not found
     */
    public User findByUsername(String username) {
        Map<String, User> users = dbManager.getAllUsers();
        
        for (User user : users.values()) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        
        return null;
    }
    
    /**
     * Get all users
     * 
     * @return List of all users
     */
    public List<User> findAll() {
        return new ArrayList<>(dbManager.getAllUsers().values());
    }
    
    /**
     * Save a new user
     * 
     * @param user The user to save
     * @return true if the save was successful, false otherwise
     */
    public boolean save(User user) {
        // Check if username already exists
        if (findByUsername(user.getUsername()) != null) {
            return false;
        }
        
        // Hash the password before saving
        user.setPassword(PasswordHasher.hashPassword(user.getPassword()));
        
        // Save the user
        return dbManager.saveUser(user);
    }
    
    /**
     * Update an existing user
     * 
     * @param user The user to update
     * @return true if the update was successful, false otherwise
     */
    public boolean update(User user) {
        // Get the existing user
        User existingUser = findById(user.getUserId());
        if (existingUser == null) {
            return false;
        }
        
        // Check if username is changing and if it already exists
        if (!existingUser.getUsername().equals(user.getUsername()) && 
                findByUsername(user.getUsername()) != null) {
            return false;
        }
        
        // Save the updated user
        return dbManager.saveUser(user);
    }
    
    /**
     * Delete a user
     * 
     * @param userId The ID of the user to delete
     * @return true if the deletion was successful, false otherwise
     */
    public boolean delete(String userId) {
        return dbManager.deleteUser(userId);
    }
    
    /**
     * Create a default admin user if no users exist in the system
     */
    private void createDefaultAdminIfNotExists() {
        if (dbManager.getAllUsers().isEmpty()) {
            System.out.println("Creating default admin and user accounts...");
            
            // Create admin
            User admin = new User();
            admin.setUserId("admin_" + System.currentTimeMillis());
            admin.setUsername("admin");
            admin.setPassword(PasswordHasher.hashPassword("admin123")); // Hash the password
            admin.setFullName("System Administrator");
            admin.setEmail("admin@bitcoinexchange.com");
            admin.setRole(com.bankapp.model.Role.ADMIN);
            
            boolean success = dbManager.saveUser(admin);
            if (success) {
                System.out.println("Default admin created successfully.");
                System.out.println("Admin Username: admin");
                System.out.println("Admin Password: admin123");
            }
            
            // Create regular user
            User user = new User();
            user.setUserId("user_" + System.currentTimeMillis());
            user.setUsername("user");
            user.setPassword(PasswordHasher.hashPassword("user123")); // Hash the password
            user.setFullName("Test User");
            user.setEmail("user@bitcoinexchange.com");
            user.setRole(com.bankapp.model.Role.USER);
            
            success = dbManager.saveUser(user);
            if (success) {
                System.out.println("Default user created successfully.");
                System.out.println("User Username: user");
                System.out.println("User Password: user123");
            }
        }
    }
}
