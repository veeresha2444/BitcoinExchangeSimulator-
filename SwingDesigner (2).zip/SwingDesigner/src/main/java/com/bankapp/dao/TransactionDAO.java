package com.bankapp.dao;

import com.bankapp.model.Transaction;
import com.bankapp.utils.DatabaseManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Data Access Object for Transaction entities
 */
public class TransactionDAO {
    private final DatabaseManager dbManager;
    
    public TransactionDAO() {
        this.dbManager = DatabaseManager.getInstance();
    }
    
    /**
     * Save a transaction (alias for save method for compatibility with BitcoinController)
     */
    public boolean saveTransaction(Transaction transaction) {
        return save(transaction);
    }
    
    /**
     * Find a transaction by ID
     * 
     * @param transactionId The transaction ID
     * @return The transaction, or null if not found
     */
    public Transaction findById(String transactionId) {
        return dbManager.getTransaction(transactionId);
    }
    
    /**
     * Find transactions by account ID
     * 
     * @param accountId The account ID
     * @return List of transactions for the account
     */
    public List<Transaction> findByAccountId(String accountId) {
        Map<String, Transaction> transactions = dbManager.getAllTransactions();
        
        return transactions.values().stream()
                .filter(transaction -> transaction.getAccountId().equals(accountId))
                .collect(Collectors.toList());
    }
    
    /**
     * Get all transactions
     * 
     * @return List of all transactions
     */
    public List<Transaction> findAll() {
        return new ArrayList<>(dbManager.getAllTransactions().values());
    }
    
    /**
     * Save a new transaction
     * 
     * @param transaction The transaction to save
     * @return true if the save was successful, false otherwise
     */
    public boolean save(Transaction transaction) {
        return dbManager.saveTransaction(transaction);
    }
    
    /**
     * Update an existing transaction
     * 
     * @param transaction The transaction to update
     * @return true if the update was successful, false otherwise
     */
    public boolean update(Transaction transaction) {
        // Check if the transaction exists
        if (findById(transaction.getTransactionId()) == null) {
            return false;
        }
        
        // Save the updated transaction
        return dbManager.saveTransaction(transaction);
    }
    
    /**
     * Delete a transaction
     * 
     * @param transactionId The ID of the transaction to delete
     * @return true if the deletion was successful, false otherwise
     */
    public boolean delete(String transactionId) {
        return dbManager.deleteTransaction(transactionId);
    }
}
