package com.bankapp.dao;

import com.bankapp.model.Account;
import com.bankapp.utils.DatabaseManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Data Access Object for Account entities
 */
public class AccountDAO {
    private final DatabaseManager dbManager;
    
    public AccountDAO() {
        this.dbManager = DatabaseManager.getInstance();
    }
    
    /**
     * Get account by ID (alias for findById for compatibility with BitcoinController)
     */
    public Account getAccountById(String accountId) {
        return findById(accountId);
    }
    
    /**
     * Get accounts by user ID (alias for findByUserId for compatibility with BitcoinController)
     */
    public List<Account> getAccountsByUserId(String userId) {
        return findByUserId(userId);
    }
    
    /**
     * Update an account (alias for update for compatibility with BitcoinController)
     */
    public boolean updateAccount(Account account) {
        return update(account);
    }
    
    /**
     * Find an account by account number
     */
    public Account findByAccountNumber(String accountNumber) {
        Map<String, Account> accounts = dbManager.getAllAccounts();
        
        return accounts.values().stream()
                .filter(account -> account.getAccountNumber().equals(accountNumber))
                .findFirst()
                .orElse(null);
    }
    
    /**
     * Get account by account number (alias for findByAccountNumber for compatibility)
     */
    public Account getAccountByAccountNumber(String accountNumber) {
        return findByAccountNumber(accountNumber);
    }
    
    /**
     * Find an account by ID
     * 
     * @param accountId The account ID
     * @return The account, or null if not found
     */
    public Account findById(String accountId) {
        return dbManager.getAccount(accountId);
    }
    
    /**
     * Find accounts by user ID
     * 
     * @param userId The user ID
     * @return List of accounts belonging to the user
     */
    public List<Account> findByUserId(String userId) {
        Map<String, Account> accounts = dbManager.getAllAccounts();
        
        return accounts.values().stream()
                .filter(account -> account.getUserId().equals(userId))
                .collect(Collectors.toList());
    }
    
    /**
     * Get all accounts
     * 
     * @return List of all accounts
     */
    public List<Account> findAll() {
        return new ArrayList<>(dbManager.getAllAccounts().values());
    }
    
    /**
     * Save a new account
     * 
     * @param account The account to save
     * @return true if the save was successful, false otherwise
     */
    public boolean save(Account account) {
        return dbManager.saveAccount(account);
    }
    
    /**
     * Update an existing account
     * 
     * @param account The account to update
     * @return true if the update was successful, false otherwise
     */
    public boolean update(Account account) {
        // Check if the account exists
        if (findById(account.getAccountId()) == null) {
            return false;
        }
        
        // Save the updated account
        return dbManager.saveAccount(account);
    }
    
    /**
     * Delete an account
     * 
     * @param accountId The ID of the account to delete
     * @return true if the deletion was successful, false otherwise
     */
    public boolean delete(String accountId) {
        return dbManager.deleteAccount(accountId);
    }
}
