package com.bankapp.view;

import com.bankapp.controller.AdminController;
import com.bankapp.model.WithdrawalRequest;

import javax.swing.*;
import java.awt.*;
import java.time.format.DateTimeFormatter;

/**
 * View for displaying and processing a withdrawal request
 */
public class WithdrawalRequestView extends JFrame {
    private final AdminController adminController;
    private final WithdrawalRequest request;
    
    private JTextField accountField;
    private JTextField userIdField;
    private JTextField amountField;
    private JTextField requestDateField;
    private JTextArea reasonArea;
    private JTextArea commentsArea;
    
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    public WithdrawalRequestView(AdminController adminController, WithdrawalRequest request) {
        this.adminController = adminController;
        this.request = request;
        
        initializeUI();
        populateFields();
    }
    
    private void initializeUI() {
        // Set up the frame
        setTitle("Withdrawal Request Details");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500, 500);
        setLocationRelativeTo(null);
        
        // Create components
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Header
        JLabel titleLabel = new JLabel("Withdrawal Request Details");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        mainPanel.add(titleLabel, BorderLayout.NORTH);
        
        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Account ID
        formPanel.add(new JLabel("Account ID:"));
        accountField = new JTextField();
        accountField.setEditable(false);
        formPanel.add(accountField);
        
        // User ID
        formPanel.add(new JLabel("User ID:"));
        userIdField = new JTextField();
        userIdField.setEditable(false);
        formPanel.add(userIdField);
        
        // Amount
        formPanel.add(new JLabel("Amount:"));
        amountField = new JTextField();
        amountField.setEditable(false);
        formPanel.add(amountField);
        
        // Request Date
        formPanel.add(new JLabel("Request Date:"));
        requestDateField = new JTextField();
        requestDateField.setEditable(false);
        formPanel.add(requestDateField);
        
        // Reason
        formPanel.add(new JLabel("Reason:"));
        reasonArea = new JTextArea();
        reasonArea.setEditable(false);
        reasonArea.setLineWrap(true);
        reasonArea.setWrapStyleWord(true);
        JScrollPane reasonScrollPane = new JScrollPane(reasonArea);
        formPanel.add(reasonScrollPane);
        
        // Admin Comments
        formPanel.add(new JLabel("Comments:"));
        commentsArea = new JTextArea();
        commentsArea.setLineWrap(true);
        commentsArea.setWrapStyleWord(true);
        JScrollPane commentsScrollPane = new JScrollPane(commentsArea);
        formPanel.add(commentsScrollPane);
        
        mainPanel.add(formPanel, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        
        JButton approveButton = new JButton("Approve");
        approveButton.addActionListener(e -> approveRequest());
        buttonPanel.add(approveButton);
        
        JButton rejectButton = new JButton("Reject");
        rejectButton.addActionListener(e -> rejectRequest());
        buttonPanel.add(rejectButton);
        
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dispose());
        buttonPanel.add(cancelButton);
        
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Add to frame
        add(mainPanel);
    }
    
    private void populateFields() {
        accountField.setText(request.getAccountId());
        userIdField.setText(request.getUserId());
        amountField.setText("$" + request.getAmount().toString());
        requestDateField.setText(request.getRequestDate().format(dateFormatter));
        reasonArea.setText(request.getReason());
    }
    
    private void approveRequest() {
        // Get the comments
        String comments = commentsArea.getText().trim();
        
        // Process the approval
        boolean success = adminController.approveWithdrawalRequest(request.getRequestId(), comments);
        if (success) {
            JOptionPane.showMessageDialog(
                    this,
                    "Withdrawal request approved successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
            dispose();
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to approve withdrawal request. Please try again.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    private void rejectRequest() {
        // Get the comments
        String comments = commentsArea.getText().trim();
        
        // Validate comments
        if (comments.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please provide a reason for rejection.",
                    "Input Required",
                    JOptionPane.WARNING_MESSAGE
            );
            commentsArea.requestFocus();
            return;
        }
        
        // Process the rejection
        boolean success = adminController.rejectWithdrawalRequest(request.getRequestId(), comments);
        if (success) {
            JOptionPane.showMessageDialog(
                    this,
                    "Withdrawal request rejected successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
            dispose();
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to reject withdrawal request. Please try again.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
