package com.bankapp.view;

import com.bankapp.controller.AccountController;
import com.bankapp.controller.BitcoinController;
import com.bankapp.model.Account;
import com.bankapp.model.Bitcoin;
import com.bankapp.utils.SessionManager;
import com.bankapp.view.components.CustomButton;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * View for Bitcoin trading functionality
 */
public class BitcoinTradingView extends JFrame {
    private static final long serialVersionUID = 1L;
    
    private final BitcoinController bitcoinController;
    private final AccountController accountController;
    
    private JLabel priceLabel;
    private JComboBox<String> accountComboBox;
    private JTextField buyAmountField;
    private JLabel buyBitcoinAmountLabel;
    private JTextField sellBitcoinAmountField;
    private JLabel sellUsdAmountLabel;
    private JLabel balanceLabel;
    private JLabel bitcoinBalanceLabel;
    private JLabel bitcoinValueLabel;
    
    private Timer priceUpdateTimer;
    
    public BitcoinTradingView() {
        this.bitcoinController = new BitcoinController();
        this.accountController = new AccountController();
        
        initializeUI();
        loadUserAccounts();
        startPriceUpdates();
    }
    
    private void initializeUI() {
        setTitle("Bitcoin Trading");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        // Top panel for Bitcoin price information
        JPanel topPanel = createPricePanel();
        
        // Center panel for trading
        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        centerPanel.add(createBuyPanel());
        centerPanel.add(createSellPanel());
        
        // Bottom panel for account information
        JPanel bottomPanel = createAccountInfoPanel();
        
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private JPanel createPricePanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.CENTER));
        panel.setBorder(BorderFactory.createTitledBorder("Bitcoin Price"));
        
        JLabel titleLabel = new JLabel("Current Bitcoin Price: ");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        priceLabel = new JLabel("$0.00");
        priceLabel.setFont(new Font("Arial", Font.BOLD, 24));
        priceLabel.setForeground(new Color(0, 128, 0));
        
        panel.add(titleLabel);
        panel.add(priceLabel);
        
        return panel;
    }
    
    private JPanel createBuyPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Buy Bitcoin"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        JLabel accountLabel = new JLabel("Select Account:");
        accountComboBox = new JComboBox<>();
        accountComboBox.addActionListener(e -> updateBalanceInfo());
        
        JLabel amountLabel = new JLabel("USD Amount:");
        buyAmountField = new JTextField(10);
        buyAmountField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                updateBuyBitcoinAmount();
            }
        });
        
        JLabel receiveLabel = new JLabel("BTC to Receive:");
        buyBitcoinAmountLabel = new JLabel("0.00000000 BTC");
        
        CustomButton buyButton = new CustomButton("Buy Bitcoin");
        buyButton.addActionListener(e -> buyBitcoin());
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(accountLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(accountComboBox, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(amountLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(buyAmountField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(receiveLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(buyBitcoinAmountLabel, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(buyButton, gbc);
        
        return panel;
    }
    
    private JPanel createSellPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Sell Bitcoin"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        JLabel sellBitcoinLabel = new JLabel("BTC Amount:");
        sellBitcoinAmountField = new JTextField(10);
        sellBitcoinAmountField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                updateSellUsdAmount();
            }
        });
        
        JLabel receiveUsdLabel = new JLabel("USD to Receive:");
        sellUsdAmountLabel = new JLabel("$0.00");
        
        CustomButton sellButton = new CustomButton("Sell Bitcoin");
        sellButton.addActionListener(e -> sellBitcoin());
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(sellBitcoinLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(sellBitcoinAmountField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(receiveUsdLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(sellUsdAmountLabel, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(sellButton, gbc);
        
        return panel;
    }
    
    private JPanel createAccountInfoPanel() {
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createTitledBorder("Account Information"));
        
        panel.add(new JLabel("USD Balance:"));
        balanceLabel = new JLabel("$0.00");
        panel.add(balanceLabel);
        
        panel.add(new JLabel("Bitcoin Balance:"));
        bitcoinBalanceLabel = new JLabel("0.00000000 BTC");
        panel.add(bitcoinBalanceLabel);
        
        panel.add(new JLabel("Bitcoin Value in USD:"));
        bitcoinValueLabel = new JLabel("$0.00");
        panel.add(bitcoinValueLabel);
        
        return panel;
    }
    
    private void loadUserAccounts() {
        String userId = SessionManager.getInstance().getCurrentUserId();
        if (userId == null) {
            JOptionPane.showMessageDialog(this, "User not logged in", "Error", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }
        
        List<Account> accounts = accountController.getAccountsByUserId(userId);
        accountComboBox.removeAllItems();
        
        for (Account account : accounts) {
            accountComboBox.addItem(account.getAccountNumber() + " - " + account.getAccountType());
        }
        
        if (accountComboBox.getItemCount() > 0) {
            accountComboBox.setSelectedIndex(0);
            updateBalanceInfo();
        }
    }
    
    private void updateBitcoinPrice() {
        BigDecimal currentPrice = bitcoinController.getCurrentBitcoinPrice();
        DecimalFormat df = new DecimalFormat("#,##0.00");
        priceLabel.setText("$" + df.format(currentPrice));
        
        // Also update calculated amounts
        updateBuyBitcoinAmount();
        updateSellUsdAmount();
        
        // Update Bitcoin value
        updateBitcoinValue();
    }
    
    private void updateBalanceInfo() {
        if (accountComboBox.getSelectedItem() == null) {
            return;
        }
        
        String selectedItem = accountComboBox.getSelectedItem().toString();
        String accountNumber = selectedItem.split(" - ")[0];
        
        Account account = accountController.getAccountByAccountNumber(accountNumber);
        if (account != null) {
            DecimalFormat dfUsd = new DecimalFormat("#,##0.00");
            DecimalFormat dfBtc = new DecimalFormat("#.00000000");
            
            balanceLabel.setText("$" + dfUsd.format(account.getBalance()));
            bitcoinBalanceLabel.setText(dfBtc.format(account.getBitcoinBalance()) + " BTC");
            
            updateBitcoinValue();
        }
    }
    
    private void updateBitcoinValue() {
        BigDecimal bitcoinBalance = BigDecimal.ZERO;
        
        if (accountComboBox.getSelectedItem() != null) {
            String selectedItem = accountComboBox.getSelectedItem().toString();
            String accountNumber = selectedItem.split(" - ")[0];
            Account account = accountController.getAccountByAccountNumber(accountNumber);
            
            if (account != null) {
                bitcoinBalance = account.getBitcoinBalance();
            }
        }
        
        BigDecimal bitcoinPrice = bitcoinController.getCurrentBitcoinPrice();
        BigDecimal bitcoinValue = bitcoinBalance.multiply(bitcoinPrice).setScale(2, RoundingMode.HALF_UP);
        
        DecimalFormat df = new DecimalFormat("#,##0.00");
        bitcoinValueLabel.setText("$" + df.format(bitcoinValue));
    }
    
    private void updateBuyBitcoinAmount() {
        try {
            String amountText = buyAmountField.getText().trim();
            if (amountText.isEmpty()) {
                buyBitcoinAmountLabel.setText("0.00000000 BTC");
                return;
            }
            
            BigDecimal usdAmount = new BigDecimal(amountText);
            BigDecimal bitcoinPrice = bitcoinController.getCurrentBitcoinPrice();
            
            if (bitcoinPrice.compareTo(BigDecimal.ZERO) > 0) {
                BigDecimal bitcoinAmount = usdAmount.divide(bitcoinPrice, 8, RoundingMode.HALF_DOWN);
                DecimalFormat df = new DecimalFormat("#.00000000");
                buyBitcoinAmountLabel.setText(df.format(bitcoinAmount) + " BTC");
            }
        } catch (NumberFormatException | ArithmeticException e) {
            buyBitcoinAmountLabel.setText("Invalid amount");
        }
    }
    
    private void updateSellUsdAmount() {
        try {
            String amountText = sellBitcoinAmountField.getText().trim();
            if (amountText.isEmpty()) {
                sellUsdAmountLabel.setText("$0.00");
                return;
            }
            
            BigDecimal bitcoinAmount = new BigDecimal(amountText);
            BigDecimal bitcoinPrice = bitcoinController.getCurrentBitcoinPrice();
            
            BigDecimal usdAmount = bitcoinAmount.multiply(bitcoinPrice).setScale(2, RoundingMode.HALF_UP);
            DecimalFormat df = new DecimalFormat("#,##0.00");
            sellUsdAmountLabel.setText("$" + df.format(usdAmount));
        } catch (NumberFormatException e) {
            sellUsdAmountLabel.setText("Invalid amount");
        }
    }
    
    private void buyBitcoin() {
        if (accountComboBox.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select an account", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            String amountText = buyAmountField.getText().trim();
            if (amountText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a USD amount", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            BigDecimal usdAmount = new BigDecimal(amountText);
            
            String selectedItem = accountComboBox.getSelectedItem().toString();
            String accountNumber = selectedItem.split(" - ")[0];
            
            Account account = accountController.getAccountByAccountNumber(accountNumber);
            if (account == null) {
                JOptionPane.showMessageDialog(this, "Account not found", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Check if the account has enough balance
            if (account.getBalance().compareTo(usdAmount) < 0) {
                JOptionPane.showMessageDialog(this, 
                    "Insufficient balance. You have $" + account.getBalance() + " available.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            boolean success = bitcoinController.buyBitcoin(account.getAccountId(), usdAmount);
            
            if (success) {
                JOptionPane.showMessageDialog(this, 
                    "Successfully bought Bitcoin! Check your transaction history for details.", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                
                // Clear input field
                buyAmountField.setText("");
                buyBitcoinAmountLabel.setText("0.00000000 BTC");
                
                // Refresh account info
                updateBalanceInfo();
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Failed to buy Bitcoin. Please try again.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid USD amount", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void sellBitcoin() {
        if (accountComboBox.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please select an account", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            String amountText = sellBitcoinAmountField.getText().trim();
            if (amountText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a Bitcoin amount", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            BigDecimal bitcoinAmount = new BigDecimal(amountText);
            
            String selectedItem = accountComboBox.getSelectedItem().toString();
            String accountNumber = selectedItem.split(" - ")[0];
            
            Account account = accountController.getAccountByAccountNumber(accountNumber);
            if (account == null) {
                JOptionPane.showMessageDialog(this, "Account not found", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Check if the account has enough Bitcoin
            if (account.getBitcoinBalance().compareTo(bitcoinAmount) < 0) {
                JOptionPane.showMessageDialog(this, 
                    "Insufficient Bitcoin balance. You have " + account.getBitcoinBalance() + " BTC available.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            boolean success = bitcoinController.sellBitcoin(account.getAccountId(), bitcoinAmount);
            
            if (success) {
                JOptionPane.showMessageDialog(this, 
                    "Successfully sold Bitcoin! Check your transaction history for details.", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                
                // Clear input field
                sellBitcoinAmountField.setText("");
                sellUsdAmountLabel.setText("$0.00");
                
                // Refresh account info
                updateBalanceInfo();
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Failed to sell Bitcoin. Please try again.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid Bitcoin amount", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void startPriceUpdates() {
        // Update price immediately
        updateBitcoinPrice();
        
        // Start periodic updates
        priceUpdateTimer = new Timer();
        priceUpdateTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> updateBitcoinPrice());
            }
        }, 10000, 10000); // Update every 10 seconds
    }
    
    @Override
    public void dispose() {
        if (priceUpdateTimer != null) {
            priceUpdateTimer.cancel();
        }
        super.dispose();
    }
}