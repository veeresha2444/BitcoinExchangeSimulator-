package com.bankapp.view;

import com.bankapp.controller.AccountController;
import com.bankapp.controller.AuthController;
import com.bankapp.controller.TransactionController;
import com.bankapp.model.Account;
import com.bankapp.model.Transaction;
import com.bankapp.model.User;
import com.bankapp.model.WithdrawalRequest;
import com.bankapp.observer.TransactionObserver;
import com.bankapp.utils.SessionManager;
import com.bankapp.view.BitcoinTradingView;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Dashboard view for regular users
 */
public class UserDashboardView extends JFrame implements TransactionObserver {
    private final AuthController authController;
    private final AccountController accountController;
    private final TransactionController transactionController;
    
    private JComboBox<Account> accountSelector;
    private JLabel balanceLabel;
    private JTable transactionTable;
    private DefaultTableModel transactionTableModel;
    private JTable pendingRequestsTable;
    private DefaultTableModel pendingRequestsTableModel;
    
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    public UserDashboardView() {
        this.authController = new AuthController();
        this.accountController = new AccountController();
        this.transactionController = new TransactionController();
        
        // Register as an observer for transactions
        accountController.registerObserver(this);
        
        initializeUI();
        loadUserData();
    }
    
    private void initializeUI() {
        // Set up the frame
        User currentUser = SessionManager.getInstance().getCurrentUser();
        setTitle("Banking System - User Dashboard - " + currentUser.getUsername());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        
        // Create main panel with border layout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create header panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel welcomeLabel = new JLabel("Welcome, " + currentUser.getFullName());
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(e -> logout());
        
        headerPanel.add(welcomeLabel, BorderLayout.WEST);
        headerPanel.add(logoutButton, BorderLayout.EAST);
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Create tabbed pane for different sections
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Accounts tab
        JPanel accountsPanel = createAccountsPanel();
        tabbedPane.addTab("Accounts", accountsPanel);
        
        // Transactions tab
        JPanel transactionsPanel = createTransactionsPanel();
        tabbedPane.addTab("Transactions", transactionsPanel);
        
        // Withdrawal Requests tab
        JPanel withdrawalRequestsPanel = createWithdrawalRequestsPanel();
        tabbedPane.addTab("Withdrawal Requests", withdrawalRequestsPanel);
        
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        // Add main panel to frame
        add(mainPanel);
    }
    
    private JPanel createAccountsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Account selector
        JPanel selectorPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        selectorPanel.add(new JLabel("Select Account:"));
        accountSelector = new JComboBox<>();
        accountSelector.setPreferredSize(new Dimension(300, 25));
        accountSelector.addActionListener(e -> updateSelectedAccount());
        selectorPanel.add(accountSelector);
        
        // Create new account button
        JButton createAccountButton = new JButton("Create New Account");
        createAccountButton.addActionListener(e -> showCreateAccountDialog());
        selectorPanel.add(createAccountButton);
        
        panel.add(selectorPanel, BorderLayout.NORTH);
        
        // Account details panel
        JPanel detailsPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        detailsPanel.setBorder(BorderFactory.createTitledBorder("Account Details"));
        
        balanceLabel = new JLabel("Balance: $0.00");
        balanceLabel.setFont(new Font("Arial", Font.BOLD, 16));
        detailsPanel.add(balanceLabel);
        
        panel.add(detailsPanel, BorderLayout.CENTER);
        
        // Action buttons panel
        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        
        JButton depositButton = new JButton("Deposit");
        depositButton.addActionListener(e -> showDepositDialog());
        actionsPanel.add(depositButton);
        
        JButton withdrawButton = new JButton("Withdraw");
        withdrawButton.addActionListener(e -> showWithdrawDialog());
        actionsPanel.add(withdrawButton);
        
        JButton bitcoinTradingButton = new JButton("Bitcoin Trading");
        bitcoinTradingButton.addActionListener(e -> openBitcoinTradingView());
        actionsPanel.add(bitcoinTradingButton);
        
        panel.add(actionsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createTransactionsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create table model with columns
        String[] columns = {"Date", "Type", "Amount", "Description", "Reference"};
        transactionTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make all cells non-editable
            }
        };
        
        // Create table with the model
        transactionTable = new JTable(transactionTableModel);
        transactionTable.getTableHeader().setReorderingAllowed(false);
        
        // Add table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(transactionTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Refresh button
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadTransactionHistory());
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(refreshButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createWithdrawalRequestsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create table model with columns
        String[] columns = {"Request Date", "Account", "Amount", "Reason", "Status"};
        pendingRequestsTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make all cells non-editable
            }
        };
        
        // Create table with the model
        pendingRequestsTable = new JTable(pendingRequestsTableModel);
        pendingRequestsTable.getTableHeader().setReorderingAllowed(false);
        
        // Add table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(pendingRequestsTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Cancel request button
        JButton cancelRequestButton = new JButton("Cancel Selected Request");
        cancelRequestButton.addActionListener(e -> cancelSelectedWithdrawalRequest());
        
        // Refresh button
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadPendingWithdrawalRequests());
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(cancelRequestButton);
        buttonPanel.add(refreshButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private void loadUserData() {
        // Load user accounts
        List<Account> userAccounts = accountController.getUserAccounts();
        
        // Clear and populate the account selector
        accountSelector.removeAllItems();
        for (Account account : userAccounts) {
            accountSelector.addItem(account);
        }
        
        // Update selected account if there are accounts
        if (!userAccounts.isEmpty()) {
            updateSelectedAccount();
        }
        
        // Load withdrawal requests
        loadPendingWithdrawalRequests();
    }
    
    private void updateSelectedAccount() {
        Account selectedAccount = (Account) accountSelector.getSelectedItem();
        if (selectedAccount != null) {
            // Update balance label
            balanceLabel.setText("Balance: $" + selectedAccount.getBalance().toString());
            
            // Load transaction history for the selected account
            loadTransactionHistory();
        }
    }
    
    private void loadTransactionHistory() {
        Account selectedAccount = (Account) accountSelector.getSelectedItem();
        if (selectedAccount == null) {
            return;
        }
        
        // Clear the table
        transactionTableModel.setRowCount(0);
        
        // Get transactions for the selected account
        List<Transaction> transactions = accountController.getTransactionHistory(selectedAccount.getAccountId());
        
        // Add transactions to the table
        for (Transaction transaction : transactions) {
            Object[] rowData = {
                transaction.getTimestamp().format(dateFormatter),
                transaction.getType(),
                transaction.isDebit() ? "-$" + transaction.getAmount() : "+$" + transaction.getAmount(),
                transaction.getDescription(),
                transaction.getReferenceNumber()
            };
            transactionTableModel.addRow(rowData);
        }
    }
    
    private void loadPendingWithdrawalRequests() {
        // Clear the table
        pendingRequestsTableModel.setRowCount(0);
        
        // Get pending withdrawal requests
        List<WithdrawalRequest> requests = transactionController.getUserPendingWithdrawalRequests();
        
        // Add requests to the table
        for (WithdrawalRequest request : requests) {
            // Find the account for this request
            Account account = null;
            for (int i = 0; i < accountSelector.getItemCount(); i++) {
                Account a = accountSelector.getItemAt(i);
                if (a.getAccountId().equals(request.getAccountId())) {
                    account = a;
                    break;
                }
            }
            
            String accountInfo = account != null ? 
                    account.getAccountType() + " (" + account.getAccountNumber() + ")" : 
                    request.getAccountId();
            
            Object[] rowData = {
                request.getRequestDate().format(dateFormatter),
                accountInfo,
                "$" + request.getAmount(),
                request.getReason(),
                request.getStatus()
            };
            pendingRequestsTableModel.addRow(rowData);
        }
    }
    
    private void showCreateAccountDialog() {
        // Define account types
        Account.AccountType[] accountTypes = Account.AccountType.values();
        
        // Show dialog to select account type
        Account.AccountType selectedType = (Account.AccountType) JOptionPane.showInputDialog(
                this,
                "Select account type:",
                "Create New Account",
                JOptionPane.QUESTION_MESSAGE,
                null,
                accountTypes,
                accountTypes[0]
        );
        
        // If user selected a type, create the account
        if (selectedType != null) {
            Account newAccount = accountController.createAccount(selectedType);
            if (newAccount != null) {
                JOptionPane.showMessageDialog(
                        this,
                        "Account created successfully!\nAccount Number: " + newAccount.getAccountNumber(),
                        "Account Created",
                        JOptionPane.INFORMATION_MESSAGE
                );
                
                // Reload user data
                loadUserData();
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "Failed to create account. Please try again.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
    
    private void showDepositDialog() {
        Account selectedAccount = (Account) accountSelector.getSelectedItem();
        if (selectedAccount == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select an account first.",
                    "No Account Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        // Create a panel with form fields
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        
        JLabel amountLabel = new JLabel("Amount:");
        JTextField amountField = new JTextField(10);
        
        JLabel descriptionLabel = new JLabel("Description:");
        JTextField descriptionField = new JTextField(20);
        
        panel.add(amountLabel);
        panel.add(amountField);
        panel.add(descriptionLabel);
        panel.add(descriptionField);
        
        // Show the dialog
        int result = JOptionPane.showConfirmDialog(
                this,
                panel,
                "Deposit Funds",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );
        
        // Process the result
        if (result == JOptionPane.OK_OPTION) {
            try {
                // Parse the amount
                BigDecimal amount = new BigDecimal(amountField.getText().trim());
                
                // Validate amount
                if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                    throw new IllegalArgumentException("Amount must be greater than zero.");
                }
                
                // Get description
                String description = descriptionField.getText().trim();
                if (description.isEmpty()) {
                    description = "Deposit";
                }
                
                // Process deposit
                boolean success = accountController.deposit(
                        selectedAccount.getAccountId(),
                        amount,
                        description
                );
                
                if (success) {
                    JOptionPane.showMessageDialog(
                            this,
                            "Deposit successful!",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    
                    // Update UI
                    updateSelectedAccount();
                } else {
                    JOptionPane.showMessageDialog(
                            this,
                            "Deposit failed. Please try again.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(
                        this,
                        "Invalid amount format. Please enter a valid number.",
                        "Input Error",
                        JOptionPane.ERROR_MESSAGE
                );
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(
                        this,
                        e.getMessage(),
                        "Input Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
    
    private void showWithdrawDialog() {
        Account selectedAccount = (Account) accountSelector.getSelectedItem();
        if (selectedAccount == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select an account first.",
                    "No Account Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        // Create a panel with form fields
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        
        JLabel amountLabel = new JLabel("Amount:");
        JTextField amountField = new JTextField(10);
        
        JLabel descriptionLabel = new JLabel("Reason:");
        JTextField descriptionField = new JTextField(20);
        
        panel.add(amountLabel);
        panel.add(amountField);
        panel.add(descriptionLabel);
        panel.add(descriptionField);
        
        // Show the dialog
        int result = JOptionPane.showConfirmDialog(
                this,
                panel,
                "Withdraw Funds",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );
        
        // Process the result
        if (result == JOptionPane.OK_OPTION) {
            try {
                // Parse the amount
                BigDecimal amount = new BigDecimal(amountField.getText().trim());
                
                // Validate amount
                if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                    throw new IllegalArgumentException("Amount must be greater than zero.");
                }
                
                if (amount.compareTo(selectedAccount.getBalance()) > 0) {
                    throw new IllegalArgumentException("Insufficient funds. Available balance: $" + 
                            selectedAccount.getBalance());
                }
                
                // Get description
                String description = descriptionField.getText().trim();
                if (description.isEmpty()) {
                    description = "Withdrawal";
                }
                
                // Process withdrawal
                boolean success = transactionController.processWithdrawal(
                        selectedAccount.getAccountId(),
                        amount,
                        description
                );
                
                if (success) {
                    // Check if the amount is over the threshold
                    if (amount.compareTo(new BigDecimal("1000.00")) > 0) {
                        JOptionPane.showMessageDialog(
                                this,
                                "Withdrawal request submitted and pending approval.",
                                "Request Submitted",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                        
                        // Reload withdrawal requests
                        loadPendingWithdrawalRequests();
                    } else {
                        JOptionPane.showMessageDialog(
                                this,
                                "Withdrawal successful!",
                                "Success",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                        
                        // Update UI
                        updateSelectedAccount();
                    }
                } else {
                    JOptionPane.showMessageDialog(
                            this,
                            "Withdrawal failed. Please try again.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(
                        this,
                        "Invalid amount format. Please enter a valid number.",
                        "Input Error",
                        JOptionPane.ERROR_MESSAGE
                );
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(
                        this,
                        e.getMessage(),
                        "Input Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
    
    private void cancelSelectedWithdrawalRequest() {
        int selectedRow = pendingRequestsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a withdrawal request to cancel.",
                    "No Request Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        // Get the list of requests
        List<WithdrawalRequest> requests = transactionController.getUserPendingWithdrawalRequests();
        if (selectedRow >= requests.size()) {
            return;
        }
        
        // Get the selected request
        WithdrawalRequest request = requests.get(selectedRow);
        
        // Confirm cancellation
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to cancel this withdrawal request?",
                "Confirm Cancellation",
                JOptionPane.YES_NO_OPTION
        );
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = transactionController.cancelWithdrawalRequest(request.getRequestId());
            if (success) {
                JOptionPane.showMessageDialog(
                        this,
                        "Withdrawal request cancelled successfully.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE
                );
                
                // Reload withdrawal requests
                loadPendingWithdrawalRequests();
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "Failed to cancel withdrawal request. Please try again.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
    
    /**
     * Open the Bitcoin Trading view
     */
    private void openBitcoinTradingView() {
        BitcoinTradingView bitcoinTradingView = new BitcoinTradingView();
        bitcoinTradingView.setVisible(true);
    }
    
    private void logout() {
        authController.logout();
        dispose();
        new LoginView(authController).setVisible(true);
    }
    
    // TransactionObserver implementation
    @Override
    public void onTransaction(Transaction transaction) {
        // Check if the transaction is for the currently selected account
        Account selectedAccount = (Account) accountSelector.getSelectedItem();
        if (selectedAccount != null && transaction.getAccountId().equals(selectedAccount.getAccountId())) {
            // Update UI
            SwingUtilities.invokeLater(this::updateSelectedAccount);
        }
    }
    
    @Override
    public void dispose() {
        // Unregister as an observer
        accountController.unregisterObserver(this);
        super.dispose();
    }
}
