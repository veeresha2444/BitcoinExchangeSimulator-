package com.bankapp.view;

import com.bankapp.controller.AccountController;
import com.bankapp.model.Account;
import com.bankapp.model.Transaction;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * View for displaying transaction history
 */
public class TransactionView extends JFrame {
    private final AccountController accountController;
    private final Account account;
    
    private DefaultTableModel tableModel;
    private JTable transactionTable;
    
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    public TransactionView(AccountController accountController, Account account) {
        this.accountController = accountController;
        this.account = account;
        
        initializeUI();
        loadTransactions();
    }
    
    private void initializeUI() {
        // Set up the frame
        setTitle("Transaction History - Account: " + account.getAccountNumber());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);
        
        // Create components
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Transaction History");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        
        JLabel accountLabel = new JLabel("Account: " + account.getAccountNumber() + 
                " | Balance: $" + account.getBalance());
        accountLabel.setHorizontalAlignment(JLabel.RIGHT);
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(accountLabel, BorderLayout.EAST);
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Transaction table
        String[] columns = {"Date", "Type", "Amount", "Description", "Reference Number", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make all cells non-editable
            }
        };
        
        transactionTable = new JTable(tableModel);
        transactionTable.getTableHeader().setReorderingAllowed(false);
        
        JScrollPane scrollPane = new JScrollPane(transactionTable);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Footer with buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadTransactions());
        
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(closeButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Add to frame
        add(mainPanel);
    }
    
    private void loadTransactions() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        // Get transactions for this account
        List<Transaction> transactions = accountController.getTransactionHistory(account.getAccountId());
        
        // Add to table
        for (Transaction transaction : transactions) {
            Object[] rowData = {
                transaction.getTimestamp().format(dateFormatter),
                transaction.getType(),
                transaction.isDebit() ? "-$" + transaction.getAmount() : "+$" + transaction.getAmount(),
                transaction.getDescription(),
                transaction.getReferenceNumber(),
                transaction.getStatus()
            };
            tableModel.addRow(rowData);
        }
    }
}
