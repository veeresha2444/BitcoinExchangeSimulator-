package com.bankapp.view;

import com.bankapp.controller.AuthController;
import com.bankapp.utils.ValidationUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Login view for user authentication
 */
public class LoginView extends JFrame {
    private final AuthController authController;
    
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JLabel errorLabel;
    private JButton loginButton;
    
    public LoginView(AuthController authController) {
        this.authController = authController;
        initializeUI();
    }
    
    private void initializeUI() {
        // Set up the frame
        setTitle("Bitcoin Exchange - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Create components
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JLabel headerLabel = new JLabel("Bitcoin Exchange");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setHorizontalAlignment(JLabel.CENTER);
        mainPanel.add(headerLabel, BorderLayout.NORTH);
        
        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        
        // Username field
        JPanel usernamePanel = new JPanel(new BorderLayout(5, 0));
        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField(20);
        usernamePanel.add(usernameLabel, BorderLayout.WEST);
        usernamePanel.add(usernameField, BorderLayout.CENTER);
        
        // Password field
        JPanel passwordPanel = new JPanel(new BorderLayout(5, 0));
        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(20);
        passwordPanel.add(passwordLabel, BorderLayout.WEST);
        passwordPanel.add(passwordField, BorderLayout.CENTER);
        
        // Add key listener to password field for enter key
        passwordField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    attemptLogin();
                }
            }
        });
        
        // Error label
        errorLabel = new JLabel("");
        errorLabel.setForeground(Color.RED);
        errorLabel.setHorizontalAlignment(JLabel.CENTER);
        
        // Login button
        loginButton = new JButton("Login");
        loginButton.addActionListener(this::loginButtonClicked);
        
        // Add components to form panel
        formPanel.add(usernamePanel);
        formPanel.add(passwordPanel);
        formPanel.add(errorLabel);
        formPanel.add(loginButton);
        
        // Add form panel to main panel
        mainPanel.add(formPanel, BorderLayout.CENTER);
        
        // Add main panel to frame
        add(mainPanel);
    }
    
    private void loginButtonClicked(ActionEvent e) {
        attemptLogin();
    }
    
    private void attemptLogin() {
        // Clear previous error
        errorLabel.setText("");
        
        // Get the input
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        // Validate the input
        if (!ValidationUtils.isValidUsername(username)) {
            errorLabel.setText("Invalid username format");
            usernameField.requestFocus();
            return;
        }
        
        if (!ValidationUtils.isValidPassword(password)) {
            errorLabel.setText("Invalid password format");
            passwordField.requestFocus();
            return;
        }
        
        // Disable login button while authenticating
        loginButton.setEnabled(false);
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        
        // Perform login in a separate thread to avoid freezing the UI
        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() {
                return authController.login(username, password);
            }
            
            @Override
            protected void done() {
                try {
                    boolean success = get();
                    if (success) {
                        // Login successful
                        dispose(); // Close the login window
                        authController.showDashboard();
                    } else {
                        // Login failed
                        errorLabel.setText("Invalid username or password");
                        passwordField.setText("");
                        passwordField.requestFocus();
                    }
                } catch (Exception ex) {
                    errorLabel.setText("An error occurred: " + ex.getMessage());
                } finally {
                    // Re-enable login button
                    loginButton.setEnabled(true);
                    setCursor(Cursor.getDefaultCursor());
                }
            }
        };
        
        worker.execute();
    }
}
