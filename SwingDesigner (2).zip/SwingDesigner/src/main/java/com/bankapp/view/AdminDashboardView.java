package com.bankapp.view;

import com.bankapp.controller.AdminController;
import com.bankapp.controller.AuthController;
import com.bankapp.model.*;
import com.bankapp.observer.WithdrawalRequestObserver;
import com.bankapp.utils.SessionManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Dashboard view for admin users
 */
public class AdminDashboardView extends JFrame implements WithdrawalRequestObserver {
    private final AuthController authController;
    private final AdminController adminController;
    
    private JTable pendingRequestsTable;
    private DefaultTableModel pendingRequestsTableModel;
    private JTable usersTable;
    private DefaultTableModel usersTableModel;
    private JTable accountsTable;
    private DefaultTableModel accountsTableModel;
    private JTable transactionsTable;
    private DefaultTableModel transactionsTableModel;
    
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    public AdminDashboardView() {
        this.authController = new AuthController();
        this.adminController = new AdminController();
        
        initializeUI();
        loadAdminData();
    }
    
    private void initializeUI() {
        // Set up the frame
        User currentUser = SessionManager.getInstance().getCurrentUser();
        setTitle("Banking System - Admin Dashboard - " + currentUser.getUsername());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        
        // Create main panel with border layout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create header panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel welcomeLabel = new JLabel("Admin Dashboard - " + currentUser.getFullName());
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(e -> logout());
        
        headerPanel.add(welcomeLabel, BorderLayout.WEST);
        headerPanel.add(logoutButton, BorderLayout.EAST);
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Create tabbed pane for different sections
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Withdrawal Approvals tab
        JPanel withdrawalApprovalsPanel = createWithdrawalApprovalsPanel();
        tabbedPane.addTab("Withdrawal Approvals", withdrawalApprovalsPanel);
        
        // Users Management tab
        JPanel usersPanel = createUsersPanel();
        tabbedPane.addTab("Users", usersPanel);
        
        // Accounts Management tab
        JPanel accountsPanel = createAccountsPanel();
        tabbedPane.addTab("Accounts", accountsPanel);
        
        // Transactions History tab
        JPanel transactionsPanel = createTransactionsPanel();
        tabbedPane.addTab("Transactions", transactionsPanel);
        
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        // Add main panel to frame
        add(mainPanel);
    }
    
    private JPanel createWithdrawalApprovalsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create table model with columns
        String[] columns = {"Request Date", "User", "Account", "Amount", "Reason"};
        pendingRequestsTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make all cells non-editable
            }
        };
        
        // Create table with the model
        pendingRequestsTable = new JTable(pendingRequestsTableModel);
        pendingRequestsTable.getTableHeader().setReorderingAllowed(false);
        
        // Add table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(pendingRequestsTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Action buttons panel
        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        JButton approveButton = new JButton("Approve Selected");
        approveButton.addActionListener(e -> approveSelectedWithdrawalRequest());
        actionsPanel.add(approveButton);
        
        JButton rejectButton = new JButton("Reject Selected");
        rejectButton.addActionListener(e -> rejectSelectedWithdrawalRequest());
        actionsPanel.add(rejectButton);
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadPendingWithdrawalRequests());
        actionsPanel.add(refreshButton);
        
        panel.add(actionsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createUsersPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create table model with columns
        String[] columns = {"User ID", "Username", "Full Name", "Email", "Role", "Status", "Last Login"};
        usersTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make all cells non-editable
            }
        };
        
        // Create table with the model
        usersTable = new JTable(usersTableModel);
        usersTable.getTableHeader().setReorderingAllowed(false);
        
        // Add table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(usersTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Action buttons panel
        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        JButton activateButton = new JButton("Activate Selected");
        activateButton.addActionListener(e -> activateSelectedUser());
        actionsPanel.add(activateButton);
        
        JButton deactivateButton = new JButton("Deactivate Selected");
        deactivateButton.addActionListener(e -> deactivateSelectedUser());
        actionsPanel.add(deactivateButton);
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadUsers());
        actionsPanel.add(refreshButton);
        
        panel.add(actionsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createAccountsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create table model with columns
        String[] columns = {"Account ID", "Account Number", "User ID", "Type", "Balance", "Status", "Created Date"};
        accountsTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make all cells non-editable
            }
        };
        
        // Create table with the model
        accountsTable = new JTable(accountsTableModel);
        accountsTable.getTableHeader().setReorderingAllowed(false);
        
        // Add table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(accountsTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Action buttons panel
        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        JButton activateButton = new JButton("Activate Selected");
        activateButton.addActionListener(e -> activateSelectedAccount());
        actionsPanel.add(activateButton);
        
        JButton deactivateButton = new JButton("Deactivate Selected");
        deactivateButton.addActionListener(e -> deactivateSelectedAccount());
        actionsPanel.add(deactivateButton);
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadAccounts());
        actionsPanel.add(refreshButton);
        
        panel.add(actionsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createTransactionsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create table model with columns
        String[] columns = {"Transaction ID", "Account ID", "Type", "Amount", "Description", "Date", "Status"};
        transactionsTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make all cells non-editable
            }
        };
        
        // Create table with the model
        transactionsTable = new JTable(transactionsTableModel);
        transactionsTable.getTableHeader().setReorderingAllowed(false);
        
        // Add table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(transactionsTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Action buttons panel
        JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadTransactions());
        actionsPanel.add(refreshButton);
        
        panel.add(actionsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private void loadAdminData() {
        loadPendingWithdrawalRequests();
        loadUsers();
        loadAccounts();
        loadTransactions();
    }
    
    private void loadPendingWithdrawalRequests() {
        // Clear the table
        pendingRequestsTableModel.setRowCount(0);
        
        // Get pending withdrawal requests
        List<WithdrawalRequest> requests = adminController.getAllPendingWithdrawalRequests();
        
        // Add requests to the table
        for (WithdrawalRequest request : requests) {
            Object[] rowData = {
                request.getRequestDate().format(dateFormatter),
                request.getUserId(),
                request.getAccountId(),
                "$" + request.getAmount(),
                request.getReason()
            };
            pendingRequestsTableModel.addRow(rowData);
        }
    }
    
    private void loadUsers() {
        // Clear the table
        usersTableModel.setRowCount(0);
        
        // Get all users
        List<User> users = adminController.getAllUsers();
        
        // Add users to the table
        for (User user : users) {
            Object[] rowData = {
                user.getUserId(),
                user.getUsername(),
                user.getFullName(),
                user.getEmail(),
                user.getRole(),
                user.isActive() ? "Active" : "Inactive",
                user.getLastLogin() != null ? user.getLastLogin().format(dateFormatter) : "Never"
            };
            usersTableModel.addRow(rowData);
        }
    }
    
    private void loadAccounts() {
        // Clear the table
        accountsTableModel.setRowCount(0);
        
        // Get all accounts
        List<Account> accounts = adminController.getAllAccounts();
        
        // Add accounts to the table
        for (Account account : accounts) {
            Object[] rowData = {
                account.getAccountId(),
                account.getAccountNumber(),
                account.getUserId(),
                account.getAccountType(),
                "$" + account.getBalance(),
                account.isActive() ? "Active" : "Inactive",
                account.getCreatedAt().format(dateFormatter)
            };
            accountsTableModel.addRow(rowData);
        }
    }
    
    private void loadTransactions() {
        // Clear the table
        transactionsTableModel.setRowCount(0);
        
        // Get all transactions
        List<Transaction> transactions = adminController.getAllTransactions();
        
        // Add transactions to the table
        for (Transaction transaction : transactions) {
            Object[] rowData = {
                transaction.getTransactionId(),
                transaction.getAccountId(),
                transaction.getType(),
                "$" + transaction.getAmount(),
                transaction.getDescription(),
                transaction.getTimestamp().format(dateFormatter),
                transaction.getStatus()
            };
            transactionsTableModel.addRow(rowData);
        }
    }
    
    private void approveSelectedWithdrawalRequest() {
        int selectedRow = pendingRequestsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a withdrawal request to approve.",
                    "No Request Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        // Get the list of requests
        List<WithdrawalRequest> requests = adminController.getAllPendingWithdrawalRequests();
        if (selectedRow >= requests.size()) {
            return;
        }
        
        // Get the selected request
        WithdrawalRequest request = requests.get(selectedRow);
        
        // Ask for comments
        String comments = JOptionPane.showInputDialog(
                this,
                "Enter approval comments (optional):",
                "Approval Comments",
                JOptionPane.PLAIN_MESSAGE
        );
        
        if (comments == null) {
            // User cancelled the input
            return;
        }
        
        // Process the approval
        boolean success = adminController.approveWithdrawalRequest(request.getRequestId(), comments);
        if (success) {
            JOptionPane.showMessageDialog(
                    this,
                    "Withdrawal request approved successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
            
            // Reload data
            loadPendingWithdrawalRequests();
            loadAccounts();
            loadTransactions();
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to approve withdrawal request. Please try again.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    private void rejectSelectedWithdrawalRequest() {
        int selectedRow = pendingRequestsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a withdrawal request to reject.",
                    "No Request Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        // Get the list of requests
        List<WithdrawalRequest> requests = adminController.getAllPendingWithdrawalRequests();
        if (selectedRow >= requests.size()) {
            return;
        }
        
        // Get the selected request
        WithdrawalRequest request = requests.get(selectedRow);
        
        // Ask for reason
        String comments = JOptionPane.showInputDialog(
                this,
                "Enter rejection reason:",
                "Rejection Reason",
                JOptionPane.PLAIN_MESSAGE
        );
        
        if (comments == null) {
            // User cancelled the input
            return;
        }
        
        if (comments.trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Rejection reason is required.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }
        
        // Process the rejection
        boolean success = adminController.rejectWithdrawalRequest(request.getRequestId(), comments);
        if (success) {
            JOptionPane.showMessageDialog(
                    this,
                    "Withdrawal request rejected successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
            
            // Reload data
            loadPendingWithdrawalRequests();
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to reject withdrawal request. Please try again.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    private void activateSelectedUser() {
        int selectedRow = usersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a user to activate.",
                    "No User Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        // Get the user ID from the table
        String userId = (String) usersTableModel.getValueAt(selectedRow, 0);
        
        // Process the activation
        boolean success = adminController.setUserStatus(userId, true);
        if (success) {
            JOptionPane.showMessageDialog(
                    this,
                    "User activated successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
            
            // Reload users
            loadUsers();
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to activate user. Please try again.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    private void deactivateSelectedUser() {
        int selectedRow = usersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a user to deactivate.",
                    "No User Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        // Get the user ID from the table
        String userId = (String) usersTableModel.getValueAt(selectedRow, 0);
        
        // Check if user is trying to deactivate themselves
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (userId.equals(currentUser.getUserId())) {
            JOptionPane.showMessageDialog(
                    this,
                    "You cannot deactivate your own account.",
                    "Operation Not Allowed",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        // Confirm deactivation
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to deactivate this user?",
                "Confirm Deactivation",
                JOptionPane.YES_NO_OPTION
        );
        
        if (confirm == JOptionPane.YES_OPTION) {
            // Process the deactivation
            boolean success = adminController.setUserStatus(userId, false);
            if (success) {
                JOptionPane.showMessageDialog(
                        this,
                        "User deactivated successfully.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE
                );
                
                // Reload users
                loadUsers();
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "Failed to deactivate user. Please try again.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
    
    private void activateSelectedAccount() {
        int selectedRow = accountsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select an account to activate.",
                    "No Account Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        // Get the account ID from the table
        String accountId = (String) accountsTableModel.getValueAt(selectedRow, 0);
        
        // Process the activation
        boolean success = adminController.setAccountStatus(accountId, true);
        if (success) {
            JOptionPane.showMessageDialog(
                    this,
                    "Account activated successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
            
            // Reload accounts
            loadAccounts();
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to activate account. Please try again.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    private void deactivateSelectedAccount() {
        int selectedRow = accountsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select an account to deactivate.",
                    "No Account Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        // Get the account ID from the table
        String accountId = (String) accountsTableModel.getValueAt(selectedRow, 0);
        
        // Confirm deactivation
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to deactivate this account?",
                "Confirm Deactivation",
                JOptionPane.YES_NO_OPTION
        );
        
        if (confirm == JOptionPane.YES_OPTION) {
            // Process the deactivation
            boolean success = adminController.setAccountStatus(accountId, false);
            if (success) {
                JOptionPane.showMessageDialog(
                        this,
                        "Account deactivated successfully.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE
                );
                
                // Reload accounts
                loadAccounts();
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "Failed to deactivate account. Please try again.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
    
    private void logout() {
        authController.logout();
        dispose();
        new LoginView(authController).setVisible(true);
    }
    
    // WithdrawalRequestObserver implementation
    @Override
    public void onWithdrawalRequest(WithdrawalRequest request) {
        // Update UI when a new withdrawal request is created
        SwingUtilities.invokeLater(this::loadPendingWithdrawalRequests);
    }
}
