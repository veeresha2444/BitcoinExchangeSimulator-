package com.bankapp.view.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Custom button component with enhanced visual design
 */
public class CustomButton extends JButton {
    private static final Color DEFAULT_BACKGROUND = new Color(64, 123, 255);
    private static final Color HOVER_BACKGROUND = new Color(41, 98, 255);
    private static final Color PRESSED_BACKGROUND = new Color(14, 69, 240);
    private static final Color TEXT_COLOR = Color.WHITE;
    private static final Font BUTTON_FONT = new Font("Arial", Font.BOLD, 14);
    private static final int BORDER_RADIUS = 10;
    
    /**
     * Constructor for CustomButton
     * 
     * @param text The text to display on the button
     */
    public CustomButton(String text) {
        super(text);
        
        // Set appearance
        setForeground(TEXT_COLOR);
        setBackground(DEFAULT_BACKGROUND);
        setFont(BUTTON_FONT);
        setFocusPainted(false);
        setBorderPainted(false);
        
        // Make button look round
        setUI(new CustomButtonUI(BORDER_RADIUS));
        
        // Add hover effects
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setBackground(HOVER_BACKGROUND);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                setBackground(DEFAULT_BACKGROUND);
            }
            
            @Override
            public void mousePressed(MouseEvent e) {
                setBackground(PRESSED_BACKGROUND);
            }
            
            @Override
            public void mouseReleased(MouseEvent e) {
                if (contains(e.getPoint())) {
                    setBackground(HOVER_BACKGROUND);
                } else {
                    setBackground(DEFAULT_BACKGROUND);
                }
            }
        });
    }
    
    // Custom UI for rounded borders
    private static class CustomButtonUI extends javax.swing.plaf.basic.BasicButtonUI {
        private final int radius;
        
        public CustomButtonUI(int radius) {
            this.radius = radius;
        }
        
        @Override
        public void paint(Graphics g, JComponent c) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            AbstractButton b = (AbstractButton) c;
            ButtonModel model = b.getModel();
            
            // Paint background
            if (model.isPressed()) {
                g2.setColor(PRESSED_BACKGROUND);
            } else if (model.isRollover()) {
                g2.setColor(HOVER_BACKGROUND);
            } else {
                g2.setColor(b.getBackground());
            }
            
            g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), radius, radius);
            
            // Paint text and icon
            super.paint(g2, c);
            g2.dispose();
        }
    }
}