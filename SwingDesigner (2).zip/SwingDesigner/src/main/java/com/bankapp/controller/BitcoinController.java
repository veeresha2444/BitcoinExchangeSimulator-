package com.bankapp.controller;

import com.bankapp.dao.AccountDAO;
import com.bankapp.dao.TransactionDAO;
import com.bankapp.model.Account;
import com.bankapp.model.Bitcoin;
import com.bankapp.model.Transaction;
import com.bankapp.model.TransactionType;
import com.bankapp.utils.SessionManager;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Controller class for handling Bitcoin trading operations
 */
public class BitcoinController {
    private final AccountDAO accountDAO;
    private final TransactionDAO transactionDAO;
    private final Bitcoin bitcoin;
    
    public BitcoinController() {
        this.accountDAO = new AccountDAO();
        this.transactionDAO = new TransactionDAO();
        this.bitcoin = Bitcoin.getInstance();
    }
    
    /**
     * Get the current Bitcoin price
     * 
     * @return Current Bitcoin price in USD
     */
    public BigDecimal getCurrentBitcoinPrice() {
        // Update the price to simulate market movement
        bitcoin.updatePrice();
        return bitcoin.getCurrentPrice();
    }
    
    /**
     * Buy Bitcoin using account balance
     * 
     * @param accountId The account ID making the purchase
     * @param usdAmount The USD amount to spend
     * @return true if successful, false otherwise
     */
    public boolean buyBitcoin(String accountId, BigDecimal usdAmount) {
        // Check parameters
        if (accountId == null || usdAmount == null || usdAmount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        
        // Get the account
        Account account = accountDAO.getAccountById(accountId);
        if (account == null) {
            return false;
        }
        
        // Check if account has enough balance
        if (account.getBalance().compareTo(usdAmount) < 0) {
            return false;
        }
        
        // Calculate Bitcoin amount at current price
        BigDecimal bitcoinAmount = bitcoin.calculateBitcoinAmount(usdAmount);
        
        // Execute the purchase
        boolean success = account.buyBitcoin(usdAmount, bitcoinAmount);
        
        if (success) {
            // Save the updated account
            accountDAO.updateAccount(account);
            
            // Create a transaction record
            Transaction transaction = new Transaction();
            transaction.setTransactionId(UUID.randomUUID().toString());
            transaction.setAccountId(accountId);
            transaction.setAmount(usdAmount);
            transaction.setTransactionType(TransactionType.BUY_BITCOIN);
            transaction.setDescription(String.format("Bought %.8f BTC at $%.2f per BTC", 
                    bitcoinAmount, bitcoin.getCurrentPrice()));
            transaction.setTimestamp(LocalDateTime.now());
            
            // Additional data for Bitcoin transactions
            transaction.setMetadata("bitcoin_amount:" + bitcoinAmount + ";bitcoin_price:" + bitcoin.getCurrentPrice());
            
            // Save the transaction
            transactionDAO.saveTransaction(transaction);
        }
        
        return success;
    }
    
    /**
     * Sell Bitcoin for USD
     * 
     * @param accountId The account ID selling Bitcoin
     * @param bitcoinAmount The amount of Bitcoin to sell
     * @return true if successful, false otherwise
     */
    public boolean sellBitcoin(String accountId, BigDecimal bitcoinAmount) {
        // Check parameters
        if (accountId == null || bitcoinAmount == null || bitcoinAmount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        
        // Get the account
        Account account = accountDAO.getAccountById(accountId);
        if (account == null) {
            return false;
        }
        
        // Check if account has enough Bitcoin
        if (account.getBitcoinBalance().compareTo(bitcoinAmount) < 0) {
            return false;
        }
        
        // Calculate USD amount at current price
        BigDecimal usdAmount = bitcoin.calculateUsdValue(bitcoinAmount);
        
        // Execute the sale
        boolean success = account.sellBitcoin(bitcoinAmount, usdAmount);
        
        if (success) {
            // Save the updated account
            accountDAO.updateAccount(account);
            
            // Create a transaction record
            Transaction transaction = new Transaction();
            transaction.setTransactionId(UUID.randomUUID().toString());
            transaction.setAccountId(accountId);
            transaction.setAmount(usdAmount);
            transaction.setTransactionType(TransactionType.SELL_BITCOIN);
            transaction.setDescription(String.format("Sold %.8f BTC at $%.2f per BTC", 
                    bitcoinAmount, bitcoin.getCurrentPrice()));
            transaction.setTimestamp(LocalDateTime.now());
            
            // Additional data for Bitcoin transactions
            transaction.setMetadata("bitcoin_amount:" + bitcoinAmount + ";bitcoin_price:" + bitcoin.getCurrentPrice());
            
            // Save the transaction
            transactionDAO.saveTransaction(transaction);
        }
        
        return success;
    }
    
    /**
     * Get the total Bitcoin holdings for the current user
     * 
     * @return Total Bitcoin balance
     */
    public BigDecimal getTotalBitcoinBalance() {
        String userId = SessionManager.getInstance().getCurrentUserId();
        if (userId == null) {
            return BigDecimal.ZERO;
        }
        
        BigDecimal totalBitcoin = BigDecimal.ZERO;
        
        for (Account account : accountDAO.getAccountsByUserId(userId)) {
            totalBitcoin = totalBitcoin.add(account.getBitcoinBalance());
        }
        
        return totalBitcoin;
    }
    
    /**
     * Get the USD value of the user's total Bitcoin holdings
     * 
     * @return USD value of Bitcoin holdings
     */
    public BigDecimal getTotalBitcoinValueInUSD() {
        BigDecimal totalBitcoin = getTotalBitcoinBalance();
        return bitcoin.calculateUsdValue(totalBitcoin);
    }
}