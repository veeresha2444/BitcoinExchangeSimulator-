package com.bankapp.controller;

import com.bankapp.dao.AccountDAO;
import com.bankapp.dao.TransactionDAO;
import com.bankapp.dao.WithdrawalRequestDAO;
import com.bankapp.model.*;
import com.bankapp.observer.WithdrawalRequestObserver;
import com.bankapp.utils.SessionManager;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Controller for handling transaction related operations
 */
public class TransactionController {
    private final AccountDAO accountDAO;
    private final TransactionDAO transactionDAO;
    private final WithdrawalRequestDAO withdrawalRequestDAO;
    private final List<WithdrawalRequestObserver> observers;
    
    // Threshold amount that requires approval
    private static final BigDecimal APPROVAL_THRESHOLD = new BigDecimal("1000.00");
    
    public TransactionController() {
        this.accountDAO = new AccountDAO();
        this.transactionDAO = new TransactionDAO();
        this.withdrawalRequestDAO = new WithdrawalRequestDAO();
        this.observers = new ArrayList<>();
    }
    
    /**
     * Process a withdrawal from an account
     * 
     * @param accountId The account ID
     * @param amount The amount to withdraw
     * @param description The description of the transaction
     * @return true if the withdrawal was processed or a request was created, false if it failed
     */
    public boolean processWithdrawal(String accountId, BigDecimal amount, String description) {
        // Input validation
        if (accountId == null || amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        
        // Get the account
        Account account = accountDAO.findById(accountId);
        if (account == null || !account.isActive()) {
            return false;
        }
        
        // Check if the current user owns this account
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null || !account.getUserId().equals(currentUser.getUserId())) {
            return false;
        }
        
        // Check if there are sufficient funds
        if (amount.compareTo(account.getBalance()) > 0) {
            return false;
        }
        
        // Check if the amount requires approval
        if (amount.compareTo(APPROVAL_THRESHOLD) > 0) {
            // Create a withdrawal request
            WithdrawalRequest request = new WithdrawalRequest(
                    accountId,
                    currentUser.getUserId(),
                    amount,
                    description != null ? description : "Withdrawal"
            );
            
            // Save the request
            if (withdrawalRequestDAO.save(request)) {
                // Notify observers
                notifyObservers(request);
                return true;
            }
            return false;
        }
        
        // For amounts below the threshold, process the withdrawal immediately
        if (!account.withdraw(amount)) {
            return false;
        }
        
        // Create a transaction record
        Transaction transaction = new Transaction(
                accountId, 
                TransactionType.WITHDRAWAL, 
                amount, 
                description != null ? description : "Withdrawal"
        );
        
        // Save the transaction
        if (!transactionDAO.save(transaction)) {
            // Rollback the withdrawal if transaction save fails
            account.deposit(amount);
            return false;
        }
        
        // Update the account
        if (!accountDAO.update(account)) {
            // Rollback if account update fails
            account.deposit(amount);
            transactionDAO.delete(transaction.getTransactionId());
            return false;
        }
        
        // Add the transaction to the account's transaction history
        account.addTransaction(transaction);
        
        return true;
    }
    
    /**
     * Get all pending withdrawal requests for the current user
     * 
     * @return List of pending withdrawal requests
     */
    public List<WithdrawalRequest> getUserPendingWithdrawalRequests() {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null) {
            return new ArrayList<>();
        }
        
        return withdrawalRequestDAO.findPendingByUserId(currentUser.getUserId());
    }
    
    /**
     * Cancel a withdrawal request
     * 
     * @param requestId The request ID
     * @return true if the cancellation was successful, false otherwise
     */
    public boolean cancelWithdrawalRequest(String requestId) {
        WithdrawalRequest request = withdrawalRequestDAO.findById(requestId);
        if (request == null || !request.isPending()) {
            return false;
        }
        
        // Check if the current user owns this request
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null || !request.getUserId().equals(currentUser.getUserId())) {
            return false;
        }
        
        // Cancel the request
        request.cancel();
        
        // Update the request
        return withdrawalRequestDAO.update(request);
    }
    
    /**
     * Register a withdrawal request observer
     * 
     * @param observer The observer to register
     */
    public void registerObserver(WithdrawalRequestObserver observer) {
        if (!observers.contains(observer)) {
            observers.add(observer);
        }
    }
    
    /**
     * Unregister a withdrawal request observer
     * 
     * @param observer The observer to unregister
     */
    public void unregisterObserver(WithdrawalRequestObserver observer) {
        observers.remove(observer);
    }
    
    /**
     * Notify all observers of a new withdrawal request
     * 
     * @param request The request to notify about
     */
    private void notifyObservers(WithdrawalRequest request) {
        for (WithdrawalRequestObserver observer : observers) {
            observer.onWithdrawalRequest(request);
        }
    }
}
