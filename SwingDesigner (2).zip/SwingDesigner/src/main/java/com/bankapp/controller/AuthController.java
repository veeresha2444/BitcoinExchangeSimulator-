package com.bankapp.controller;

import com.bankapp.dao.UserDAO;
import com.bankapp.model.User;
import com.bankapp.utils.PasswordHasher;
import com.bankapp.utils.SessionManager;
import com.bankapp.view.AdminDashboardView;
import com.bankapp.view.UserDashboardView;

import java.time.LocalDateTime;

/**
 * Controller for handling authentication related operations
 */
public class AuthController {
    private final UserDAO userDAO;
    
    public AuthController() {
        this.userDAO = new UserDAO();
    }
    
    /**
     * Attempts to authenticate a user with the provided credentials
     * 
     * @param username The username
     * @param password The password
     * @return true if authentication succeeds, false otherwise
     */
    public boolean login(String username, String password) {
        // Input validation
        if (username == null || username.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            return false;
        }
        
        // Find the user
        User user = userDAO.findByUsername(username);
        if (user == null) {
            return false;
        }
        
        // Check if the user is active
        if (!user.isActive()) {
            return false;
        }
        
        // Verify the password
        if (!PasswordHasher.verifyPassword(password, user.getPassword())) {
            return false;
        }
        
        // Update the last login time
        user.setLastLogin(LocalDateTime.now());
        userDAO.update(user);
        
        // Set the user in the session
        SessionManager.getInstance().setCurrentUser(user);
        
        return true;
    }
    
    /**
     * Logs out the current user
     */
    public void logout() {
        SessionManager.getInstance().clearSession();
    }
    
    /**
     * Check if a user is authenticated
     * 
     * @return true if a user is logged in, false otherwise
     */
    public boolean isAuthenticated() {
        return SessionManager.getInstance().getCurrentUser() != null;
    }
    
    /**
     * Check if the current user is an admin
     * 
     * @return true if the current user is an admin, false otherwise
     */
    public boolean isAdmin() {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        return currentUser != null && currentUser.isAdmin();
    }
    
    /**
     * Get the current authenticated user
     * 
     * @return The current user, or null if not authenticated
     */
    public User getCurrentUser() {
        return SessionManager.getInstance().getCurrentUser();
    }
    
    /**
     * Display the appropriate dashboard based on the user's role
     */
    public void showDashboard() {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null) {
            return;
        }
        
        if (currentUser.isAdmin()) {
            new AdminDashboardView().setVisible(true);
        } else {
            new UserDashboardView().setVisible(true);
        }
    }
}
