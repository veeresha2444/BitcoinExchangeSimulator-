package com.bankapp.controller;

import com.bankapp.dao.AccountDAO;
import com.bankapp.dao.TransactionDAO;
import com.bankapp.dao.UserDAO;
import com.bankapp.dao.WithdrawalRequestDAO;
import com.bankapp.model.*;
import com.bankapp.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Controller for handling admin related operations
 */
public class AdminController {
    private final WithdrawalRequestDAO withdrawalRequestDAO;
    private final AccountDAO accountDAO;
    private final UserDAO userDAO;
    private final TransactionDAO transactionDAO;
    
    public AdminController() {
        this.withdrawalRequestDAO = new WithdrawalRequestDAO();
        this.accountDAO = new AccountDAO();
        this.userDAO = new UserDAO();
        this.transactionDAO = new TransactionDAO();
    }
    
    /**
     * Get all pending withdrawal requests
     * 
     * @return List of pending withdrawal requests
     */
    public List<WithdrawalRequest> getAllPendingWithdrawalRequests() {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null || !currentUser.isAdmin()) {
            return new ArrayList<>();
        }
        
        return withdrawalRequestDAO.findAllPending();
    }
    
    /**
     * Approve a withdrawal request
     * 
     * @param requestId The request ID
     * @param comments Admin comments for the approval
     * @return true if the approval was successful, false otherwise
     */
    public boolean approveWithdrawalRequest(String requestId, String comments) {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null || !currentUser.isAdmin()) {
            return false;
        }
        
        WithdrawalRequest request = withdrawalRequestDAO.findById(requestId);
        if (request == null || !request.isPending()) {
            return false;
        }
        
        // Get the account
        Account account = accountDAO.findById(request.getAccountId());
        if (account == null || !account.isActive()) {
            return false;
        }
        
        // Check if there are sufficient funds
        if (request.getAmount().compareTo(account.getBalance()) > 0) {
            return false;
        }
        
        // Perform the withdrawal
        if (!account.withdraw(request.getAmount())) {
            return false;
        }
        
        // Create a transaction record
        Transaction transaction = new Transaction(
                request.getAccountId(), 
                TransactionType.WITHDRAWAL, 
                request.getAmount(), 
                request.getReason()
        );
        
        // Save the transaction
        if (!transactionDAO.save(transaction)) {
            // Rollback the withdrawal if transaction save fails
            account.deposit(request.getAmount());
            return false;
        }
        
        // Update the account
        if (!accountDAO.update(account)) {
            // Rollback if account update fails
            account.deposit(request.getAmount());
            transactionDAO.delete(transaction.getTransactionId());
            return false;
        }
        
        // Add the transaction to the account's transaction history
        account.addTransaction(transaction);
        
        // Approve the request
        request.approve(currentUser.getUserId(), comments);
        
        // Update the request
        return withdrawalRequestDAO.update(request);
    }
    
    /**
     * Reject a withdrawal request
     * 
     * @param requestId The request ID
     * @param comments Admin comments for the rejection
     * @return true if the rejection was successful, false otherwise
     */
    public boolean rejectWithdrawalRequest(String requestId, String comments) {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null || !currentUser.isAdmin()) {
            return false;
        }
        
        WithdrawalRequest request = withdrawalRequestDAO.findById(requestId);
        if (request == null || !request.isPending()) {
            return false;
        }
        
        // Reject the request
        request.reject(currentUser.getUserId(), comments);
        
        // Update the request
        return withdrawalRequestDAO.update(request);
    }
    
    /**
     * Get all users in the system
     * 
     * @return List of users
     */
    public List<User> getAllUsers() {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null || !currentUser.isAdmin()) {
            return new ArrayList<>();
        }
        
        return userDAO.findAll();
    }
    
    /**
     * Get all accounts in the system
     * 
     * @return List of accounts
     */
    public List<Account> getAllAccounts() {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null || !currentUser.isAdmin()) {
            return new ArrayList<>();
        }
        
        return accountDAO.findAll();
    }
    
    /**
     * Get all transactions in the system
     * 
     * @return List of transactions
     */
    public List<Transaction> getAllTransactions() {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null || !currentUser.isAdmin()) {
            return new ArrayList<>();
        }
        
        return transactionDAO.findAll();
    }
    
    /**
     * Activate or deactivate a user account
     * 
     * @param userId The user ID
     * @param active The active status to set
     * @return true if the operation was successful, false otherwise
     */
    public boolean setUserStatus(String userId, boolean active) {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null || !currentUser.isAdmin()) {
            return false;
        }
        
        User user = userDAO.findById(userId);
        if (user == null) {
            return false;
        }
        
        user.setActive(active);
        return userDAO.update(user);
    }
    
    /**
     * Activate or deactivate a bank account
     * 
     * @param accountId The account ID
     * @param active The active status to set
     * @return true if the operation was successful, false otherwise
     */
    public boolean setAccountStatus(String accountId, boolean active) {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null || !currentUser.isAdmin()) {
            return false;
        }
        
        Account account = accountDAO.findById(accountId);
        if (account == null) {
            return false;
        }
        
        account.setActive(active);
        return accountDAO.update(account);
    }
}
