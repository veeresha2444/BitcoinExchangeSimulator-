package com.bankapp.controller;

import com.bankapp.dao.AccountDAO;
import com.bankapp.dao.TransactionDAO;
import com.bankapp.model.Account;
import com.bankapp.model.Transaction;
import com.bankapp.model.TransactionType;
import com.bankapp.model.User;
import com.bankapp.observer.TransactionObserver;
import com.bankapp.utils.SessionManager;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Controller for handling account related operations
 */
public class AccountController {
    private final AccountDAO accountDAO;
    private final TransactionDAO transactionDAO;
    private final List<TransactionObserver> observers;
    
    public AccountController() {
        this.accountDAO = new AccountDAO();
        this.transactionDAO = new TransactionDAO();
        this.observers = new ArrayList<>();
    }
    
    /**
     * Get all accounts for the current user
     * 
     * @return List of accounts
     */
    public List<Account> getUserAccounts() {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null) {
            return new ArrayList<>();
        }
        
        return accountDAO.findByUserId(currentUser.getUserId());
    }
    
    /**
     * Get an account by its ID
     * 
     * @param accountId The account ID
     * @return The account, or null if not found
     */
    public Account getAccount(String accountId) {
        return accountDAO.findById(accountId);
    }
    
    /**
     * Get accounts by user ID
     * 
     * @param userId The user ID
     * @return List of accounts
     */
    public List<Account> getAccountsByUserId(String userId) {
        return accountDAO.findByUserId(userId);
    }
    
    /**
     * Get account by account number
     * 
     * @param accountNumber The account number
     * @return The account, or null if not found
     */
    public Account getAccountByAccountNumber(String accountNumber) {
        return accountDAO.findByAccountNumber(accountNumber);
    }
    
    /**
     * Create a new account for the current user
     * 
     * @param accountType The type of account to create
     * @return The newly created account, or null if creation failed
     */
    public Account createAccount(Account.AccountType accountType) {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null) {
            return null;
        }
        
        Account account = new Account(currentUser.getUserId(), accountType);
        if (accountDAO.save(account)) {
            return account;
        }
        
        return null;
    }
    
    /**
     * Perform a deposit to an account
     * 
     * @param accountId The account ID
     * @param amount The amount to deposit
     * @param description The description of the transaction
     * @return true if the deposit was successful, false otherwise
     */
    public boolean deposit(String accountId, BigDecimal amount, String description) {
        // Input validation
        if (accountId == null || amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        
        // Get the account
        Account account = accountDAO.findById(accountId);
        if (account == null || !account.isActive()) {
            return false;
        }
        
        // Check if the current user owns this account
        User currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null || !account.getUserId().equals(currentUser.getUserId())) {
            return false;
        }
        
        // Perform the deposit
        if (!account.deposit(amount)) {
            return false;
        }
        
        // Create a transaction record
        Transaction transaction = new Transaction(
                accountId, 
                TransactionType.DEPOSIT, 
                amount, 
                description != null ? description : "Deposit"
        );
        
        // Save the transaction
        if (!transactionDAO.save(transaction)) {
            // Rollback the deposit if transaction save fails
            account.withdraw(amount);
            return false;
        }
        
        // Update the account
        if (!accountDAO.update(account)) {
            // Rollback if account update fails
            account.withdraw(amount);
            transactionDAO.delete(transaction.getTransactionId());
            return false;
        }
        
        // Add the transaction to the account's transaction history
        account.addTransaction(transaction);
        
        // Notify observers
        notifyObservers(transaction);
        
        return true;
    }
    
    /**
     * Get the transaction history for an account
     * 
     * @param accountId The account ID
     * @return List of transactions
     */
    public List<Transaction> getTransactionHistory(String accountId) {
        if (accountId == null) {
            return new ArrayList<>();
        }
        
        return transactionDAO.findByAccountId(accountId);
    }
    
    /**
     * Register a transaction observer
     * 
     * @param observer The observer to register
     */
    public void registerObserver(TransactionObserver observer) {
        if (!observers.contains(observer)) {
            observers.add(observer);
        }
    }
    
    /**
     * Unregister a transaction observer
     * 
     * @param observer The observer to unregister
     */
    public void unregisterObserver(TransactionObserver observer) {
        observers.remove(observer);
    }
    
    /**
     * Notify all observers of a new transaction
     * 
     * @param transaction The transaction to notify about
     */
    private void notifyObservers(Transaction transaction) {
        for (TransactionObserver observer : observers) {
            observer.onTransaction(transaction);
        }
    }
}
