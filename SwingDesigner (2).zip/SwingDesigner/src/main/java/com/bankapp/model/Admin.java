package com.bankapp.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Admin class extends User with additional administrative privileges
 */
public class Admin extends User {
    private static final long serialVersionUID = 1L;
    
    private String employeeId;
    private String department;
    private LocalDateTime lastActivityTime;
    private List<String> permissions;

    // Default constructor
    public Admin() {
        super();
        setRole(Role.ADMIN);
        this.permissions = new ArrayList<>();
        this.lastActivityTime = LocalDateTime.now();
    }

    // Constructor with required fields
    public Admin(String userId, String username, String password, String fullName, String email, 
                 String employeeId, String department) {
        super(userId, username, password, fullName, email);
        setRole(Role.ADMIN);
        this.employeeId = employeeId;
        this.department = department;
        this.permissions = new ArrayList<>();
        this.lastActivityTime = LocalDateTime.now();
    }

    // Getters and Setters
    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public LocalDateTime getLastActivityTime() {
        return lastActivityTime;
    }

    public void setLastActivityTime(LocalDateTime lastActivityTime) {
        this.lastActivityTime = lastActivityTime;
    }

    public List<String> getPermissions() {
        return permissions;
    }

    public void setPermissions(List<String> permissions) {
        this.permissions = permissions;
    }
    
    public void addPermission(String permission) {
        if (!this.permissions.contains(permission)) {
            this.permissions.add(permission);
        }
    }
    
    public void removePermission(String permission) {
        this.permissions.remove(permission);
    }
    
    public boolean hasPermission(String permission) {
        return this.permissions.contains(permission);
    }
    
    // Update the last activity time
    public void updateLastActivity() {
        this.lastActivityTime = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return "Admin{" +
                "userId='" + getUserId() + '\'' +
                ", username='" + getUsername() + '\'' +
                ", fullName='" + getFullName() + '\'' +
                ", employeeId='" + employeeId + '\'' +
                ", department='" + department + '\'' +
                '}';
    }
}
