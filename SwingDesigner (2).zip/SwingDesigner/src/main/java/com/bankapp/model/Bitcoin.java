package com.bankapp.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Random;

/**
 * Bitcoin model class for the Bitcoin Exchange Simulator
 * Manages Bitcoin price and user holdings
 */
public class Bitcoin implements Serializable {
    private static final long serialVersionUID = 1L;
    
    // Singleton instance
    private static Bitcoin instance;
    
    // Bitcoin properties
    private BigDecimal currentPrice;
    private LocalDateTime lastUpdated;
    private final Random random = new Random();
    
    // Price range for simulation
    private final BigDecimal MIN_PRICE = new BigDecimal("15000.00");
    private final BigDecimal MAX_PRICE = new BigDecimal("75000.00");
    private final BigDecimal MAX_CHANGE_PERCENT = new BigDecimal("0.05"); // 5% max change
    
    // Private constructor for singleton
    private Bitcoin() {
        // Initialize with a random price between MIN_PRICE and MAX_PRICE
        this.currentPrice = generateInitialPrice();
        this.lastUpdated = LocalDateTime.now();
    }
    
    /**
     * Get the singleton instance of Bitcoin
     * 
     * @return Bitcoin instance
     */
    public static synchronized Bitcoin getInstance() {
        if (instance == null) {
            instance = new Bitcoin();
        }
        return instance;
    }
    
    /**
     * Generate an initial random price for Bitcoin
     * 
     * @return Initial price
     */
    private BigDecimal generateInitialPrice() {
        BigDecimal range = MAX_PRICE.subtract(MIN_PRICE);
        BigDecimal randomFactor = new BigDecimal(random.nextDouble());
        return MIN_PRICE.add(range.multiply(randomFactor)).setScale(2, BigDecimal.ROUND_HALF_UP);
    }
    
    /**
     * Update the Bitcoin price with a random fluctuation
     * Simulates market movement
     */
    public void updatePrice() {
        // Generate a random percent change between -5% and +5%
        double changePercent = (random.nextDouble() * 2 - 1) * MAX_CHANGE_PERCENT.doubleValue();
        
        // Calculate new price
        BigDecimal changeAmount = currentPrice.multiply(new BigDecimal(changePercent));
        BigDecimal newPrice = currentPrice.add(changeAmount).setScale(2, BigDecimal.ROUND_HALF_UP);
        
        // Ensure the price stays within defined bounds
        if (newPrice.compareTo(MIN_PRICE) < 0) {
            newPrice = MIN_PRICE;
        } else if (newPrice.compareTo(MAX_PRICE) > 0) {
            newPrice = MAX_PRICE;
        }
        
        // Update price and timestamp
        currentPrice = newPrice;
        lastUpdated = LocalDateTime.now();
    }
    
    /**
     * Calculate the amount of Bitcoin that can be purchased with the given USD amount
     * 
     * @param usdAmount The amount in USD to spend
     * @return The amount of Bitcoin that can be purchased
     */
    public BigDecimal calculateBitcoinAmount(BigDecimal usdAmount) {
        if (usdAmount.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        
        // Bitcoin is divisible to 8 decimal places (satoshis)
        return usdAmount.divide(currentPrice, 8, BigDecimal.ROUND_HALF_DOWN);
    }
    
    /**
     * Calculate the USD value of the given Bitcoin amount
     * 
     * @param bitcoinAmount The amount of Bitcoin
     * @return The value in USD
     */
    public BigDecimal calculateUsdValue(BigDecimal bitcoinAmount) {
        if (bitcoinAmount.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO;
        }
        
        return bitcoinAmount.multiply(currentPrice).setScale(2, BigDecimal.ROUND_HALF_UP);
    }
    
    // Getters
    public BigDecimal getCurrentPrice() {
        return currentPrice;
    }
    
    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }
    
    @Override
    public String toString() {
        return "Bitcoin{" +
                "currentPrice=" + currentPrice +
                ", lastUpdated=" + lastUpdated +
                '}';
    }
}