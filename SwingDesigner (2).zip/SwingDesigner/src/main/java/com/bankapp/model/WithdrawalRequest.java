package com.bankapp.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * WithdrawalRequest class represents a withdrawal request that requires admin approval
 */
public class WithdrawalRequest implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String requestId;
    private String accountId;
    private String userId;
    private BigDecimal amount;
    private String reason;
    private LocalDateTime requestDate;
    private LocalDateTime processedDate;
    private RequestStatus status;
    private String processedBy;
    private String adminComments;
    
    public enum RequestStatus {
        PENDING,
        APPROVED,
        REJECTED,
        CANCELLED
    }

    // Default constructor
    public WithdrawalRequest() {
        this.requestId = UUID.randomUUID().toString();
        this.requestDate = LocalDateTime.now();
        this.status = RequestStatus.PENDING;
    }
    
    // Constructor with required fields
    public WithdrawalRequest(String accountId, String userId, BigDecimal amount, String reason) {
        this();
        this.accountId = accountId;
        this.userId = userId;
        this.amount = amount;
        this.reason = reason;
    }
    
    // Approve the withdrawal request
    public void approve(String adminId, String comments) {
        this.status = RequestStatus.APPROVED;
        this.processedDate = LocalDateTime.now();
        this.processedBy = adminId;
        this.adminComments = comments;
    }
    
    // Reject the withdrawal request
    public void reject(String adminId, String comments) {
        this.status = RequestStatus.REJECTED;
        this.processedDate = LocalDateTime.now();
        this.processedBy = adminId;
        this.adminComments = comments;
    }
    
    // Cancel the withdrawal request
    public void cancel() {
        this.status = RequestStatus.CANCELLED;
        this.processedDate = LocalDateTime.now();
    }
    
    // Check if the request is pending
    public boolean isPending() {
        return this.status == RequestStatus.PENDING;
    }
    
    // Getters and Setters
    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public LocalDateTime getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(LocalDateTime requestDate) {
        this.requestDate = requestDate;
    }

    public LocalDateTime getProcessedDate() {
        return processedDate;
    }

    public void setProcessedDate(LocalDateTime processedDate) {
        this.processedDate = processedDate;
    }

    public RequestStatus getStatus() {
        return status;
    }

    public void setStatus(RequestStatus status) {
        this.status = status;
    }

    public String getProcessedBy() {
        return processedBy;
    }

    public void setProcessedBy(String processedBy) {
        this.processedBy = processedBy;
    }

    public String getAdminComments() {
        return adminComments;
    }

    public void setAdminComments(String adminComments) {
        this.adminComments = adminComments;
    }

    @Override
    public String toString() {
        return "WithdrawalRequest{" +
                "requestId='" + requestId + '\'' +
                ", accountId='" + accountId + '\'' +
                ", userId='" + userId + '\'' +
                ", amount=" + amount +
                ", requestDate=" + requestDate +
                ", status=" + status +
                '}';
    }
}
