package com.bankapp.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Account class represents a bank account in the system
 */
public class Account implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String accountId;
    private String accountNumber;
    private String userId;
    private AccountType accountType;
    private BigDecimal balance;         // USD balance
    private BigDecimal bitcoinBalance;  // Bitcoin balance
    private LocalDateTime createdAt;
    private LocalDateTime lastUpdated;
    private boolean isActive;
    private List<Transaction> transactions;
    
    public enum AccountType {
        FIAT,       // Regular USD account
        CRYPTO,     // Bitcoin account
        EXCHANGE    // Account that can hold both USD and Bitcoin
    }
    
    // Default constructor
    public Account() {
        this.accountId = UUID.randomUUID().toString();
        this.accountNumber = generateAccountNumber();
        this.balance = BigDecimal.ZERO;
        this.bitcoinBalance = BigDecimal.ZERO;
        this.createdAt = LocalDateTime.now();
        this.lastUpdated = LocalDateTime.now();
        this.isActive = true;
        this.transactions = new ArrayList<>();
    }
    
    // Constructor with required fields
    public Account(String userId, AccountType accountType) {
        this();
        this.userId = userId;
        this.accountType = accountType;
    }
    
    // Generate a random account number
    private String generateAccountNumber() {
        return String.format("%010d", Math.abs(UUID.randomUUID().getMostSignificantBits() % 10000000000L));
    }
    
    // Deposit money into the account
    public synchronized boolean deposit(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        
        this.balance = this.balance.add(amount);
        this.lastUpdated = LocalDateTime.now();
        return true;
    }
    
    // Withdraw money from the account
    public synchronized boolean withdraw(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0 || amount.compareTo(this.balance) > 0) {
            return false;
        }
        
        this.balance = this.balance.subtract(amount);
        this.lastUpdated = LocalDateTime.now();
        return true;
    }
    
    // Add a transaction to the account's history
    public void addTransaction(Transaction transaction) {
        if (transactions == null) {
            transactions = new ArrayList<>();
        }
        transactions.add(transaction);
    }
    
    /**
     * Buy Bitcoin with USD
     * 
     * @param usdAmount Amount of USD to spend
     * @param bitcoinAmount Amount of Bitcoin to buy
     * @return true if successful, false otherwise
     */
    public synchronized boolean buyBitcoin(BigDecimal usdAmount, BigDecimal bitcoinAmount) {
        // Check if the account has enough USD balance
        if (usdAmount.compareTo(BigDecimal.ZERO) <= 0 || 
            bitcoinAmount.compareTo(BigDecimal.ZERO) <= 0 || 
            usdAmount.compareTo(this.balance) > 0) {
            return false;
        }
        
        // Deduct USD from balance
        this.balance = this.balance.subtract(usdAmount);
        
        // Add Bitcoin to bitcoinBalance
        if (this.bitcoinBalance == null) {
            this.bitcoinBalance = BigDecimal.ZERO;
        }
        this.bitcoinBalance = this.bitcoinBalance.add(bitcoinAmount);
        
        this.lastUpdated = LocalDateTime.now();
        return true;
    }
    
    /**
     * Sell Bitcoin for USD
     * 
     * @param bitcoinAmount Amount of Bitcoin to sell
     * @param usdAmount Amount of USD to receive
     * @return true if successful, false otherwise
     */
    public synchronized boolean sellBitcoin(BigDecimal bitcoinAmount, BigDecimal usdAmount) {
        // Check if the account has enough Bitcoin balance
        if (this.bitcoinBalance == null) {
            this.bitcoinBalance = BigDecimal.ZERO;
            return false;
        }
        
        if (bitcoinAmount.compareTo(BigDecimal.ZERO) <= 0 || 
            usdAmount.compareTo(BigDecimal.ZERO) <= 0 || 
            bitcoinAmount.compareTo(this.bitcoinBalance) > 0) {
            return false;
        }
        
        // Deduct Bitcoin from bitcoinBalance
        this.bitcoinBalance = this.bitcoinBalance.subtract(bitcoinAmount);
        
        // Add USD to balance
        this.balance = this.balance.add(usdAmount);
        
        this.lastUpdated = LocalDateTime.now();
        return true;
    }
    
    // Getters and Setters
    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public AccountType getAccountType() {
        return accountType;
    }

    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
    
    public BigDecimal getBitcoinBalance() {
        if (bitcoinBalance == null) {
            bitcoinBalance = BigDecimal.ZERO;
        }
        return bitcoinBalance;
    }

    public void setBitcoinBalance(BigDecimal bitcoinBalance) {
        this.bitcoinBalance = bitcoinBalance;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDateTime lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    @Override
    public String toString() {
        return "Account{" +
                "accountId='" + accountId + '\'' +
                ", accountNumber='" + accountNumber + '\'' +
                ", userId='" + userId + '\'' +
                ", accountType=" + accountType +
                ", balance=" + balance + " USD" +
                ", bitcoinBalance=" + getBitcoinBalance() + " BTC" +
                ", isActive=" + isActive +
                '}';
    }
}
