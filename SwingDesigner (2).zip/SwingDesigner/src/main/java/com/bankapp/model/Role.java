package com.bankapp.model;

/**
 * Enumeration representing different user roles in the system
 */
public enum Role {
    USER("Regular User"),
    ADMIN("Administrator");
    
    private final String displayName;
    
    Role(String displayName) {
        this.displayName = displayName;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    @Override
    public String toString() {
        return displayName;
    }
}
