package com.bankapp.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Transaction class represents a financial transaction in the system
 */
public class Transaction implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String transactionId;
    private String accountId;
    private TransactionType type;
    private BigDecimal amount;
    private String description;
    private LocalDateTime timestamp;
    private String relatedTransactionId; // For transfers
    private String referenceNumber;
    private String status;
    private String metadata; // Additional information for Bitcoin transactions

    // Default constructor
    public Transaction() {
        this.transactionId = UUID.randomUUID().toString();
        this.timestamp = LocalDateTime.now();
        this.referenceNumber = generateReferenceNumber();
        this.status = "COMPLETED";
    }
    
    // Constructor with required fields
    public Transaction(String accountId, TransactionType type, BigDecimal amount, String description) {
        this();
        this.accountId = accountId;
        this.type = type;
        this.amount = amount;
        this.description = description;
    }
    
    // Generate a unique reference number
    private String generateReferenceNumber() {
        return "TXN" + System.currentTimeMillis() % 1000000000;
    }
    
    // Check if the transaction is a debit (money going out)
    public boolean isDebit() {
        return type == TransactionType.WITHDRAWAL || type == TransactionType.TRANSFER_OUT;
    }
    
    // Check if the transaction is a credit (money coming in)
    public boolean isCredit() {
        return type == TransactionType.DEPOSIT || type == TransactionType.TRANSFER_IN;
    }

    // Getters and Setters
    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public TransactionType getType() {
        return type;
    }

    public void setType(TransactionType type) {
        this.type = type;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getRelatedTransactionId() {
        return relatedTransactionId;
    }

    public void setRelatedTransactionId(String relatedTransactionId) {
        this.relatedTransactionId = relatedTransactionId;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getMetadata() {
        return metadata;
    }
    
    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }
    
    /**
     * Alias for setType to maintain compatibility with BitcoinController
     */
    public void setTransactionType(TransactionType type) {
        setType(type);
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "transactionId='" + transactionId + '\'' +
                ", accountId='" + accountId + '\'' +
                ", type=" + type +
                ", amount=" + amount +
                ", description='" + description + '\'' +
                ", timestamp=" + timestamp +
                ", status='" + status + '\'' +
                '}';
    }
}
