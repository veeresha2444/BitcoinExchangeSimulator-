package com.bankapp;

import com.bankapp.controller.AuthController;
import com.bankapp.factory.UserFactory;
import com.bankapp.model.Admin;
import com.bankapp.model.User;
import com.bankapp.utils.DatabaseManager;
import com.bankapp.view.LoginView;

import javax.swing.*;
import java.io.File;

/**
 * Main entry point for the Banking Application
 * Initializes the application, sets up the database, and displays the login screen
 */
public class Main {
    // Default admin credentials
    private static final String DEFAULT_ADMIN_USERNAME = "admin";
    private static final String DEFAULT_ADMIN_PASSWORD = "admin123";
    
    public static void main(String[] args) {
        // Set the look and feel to the system default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Initialize the database
        DatabaseManager.getInstance().initialize();
        
        // The default admin user will be created by UserDAO if needed
        System.out.println("Database initialized");
        
        // Create and display the login view
        System.out.println("===== Bitcoin Exchange Simulator =====");
        System.out.println("Starting application...");
        System.out.println("Initializing UI components...");
        
        try {
            // Create the authentication controller
            AuthController authController = new AuthController();
            System.out.println("Auth controller initialized successfully");
            
            // Create the login view with the controller
            LoginView loginView = new LoginView(authController);
            System.out.println("Login view created successfully");
            
            // Display the login view
            loginView.setVisible(true);
            System.out.println("Login window should now be visible");
            System.out.println("Default login credentials:");
            System.out.println("Admin - Username: admin, Password: admin123");
            System.out.println("User - Username: user, Password: user123");
        } catch (Exception e) {
            System.err.println("Error initializing UI: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Create a default admin user if no users exist in the database
     */
    private static void createDefaultAdmin() {
        DatabaseManager dbManager = DatabaseManager.getInstance();
        
        // Check if we need to create default users
        if (dbManager.getAllUsers().isEmpty()) {
            System.out.println("Creating default admin user...");
            
            // Create admin user
            Admin admin = UserFactory.createAdminUser(
                DEFAULT_ADMIN_USERNAME,
                DEFAULT_ADMIN_PASSWORD,
                "Administrator",
                "admin@bankapp.com",
                "EMP123456",
                "System Administration"
            );
            
            // Save the admin user
            boolean success = dbManager.saveUser(admin);
            if (success) {
                System.out.println("Default admin created successfully.");
                System.out.println("Username: " + DEFAULT_ADMIN_USERNAME);
                System.out.println("Password: " + DEFAULT_ADMIN_PASSWORD);
            } else {
                System.err.println("Failed to create default admin user.");
            }
            
            // Create a test regular user
            User user = UserFactory.createRegularUser(
                "user",
                "user123",
                "Test User",
                "user@bankapp.com"
            );
            
            // Save the regular user
            dbManager.saveUser(user);
        }
    }
}
