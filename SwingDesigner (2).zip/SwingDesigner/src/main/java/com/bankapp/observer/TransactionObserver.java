package com.bankapp.observer;

import com.bankapp.model.Transaction;

/**
 * Observer interface for transaction events
 * Implements the Observer design pattern
 */
public interface TransactionObserver {
    /**
     * Called when a transaction is created or updated
     * 
     * @param transaction The transaction that was created or updated
     */
    void onTransaction(Transaction transaction);
}
