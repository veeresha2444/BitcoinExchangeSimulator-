package com.bankapp.observer;

import com.bankapp.model.WithdrawalRequest;

/**
 * Observer interface for withdrawal request events
 * Implements the Observer design pattern
 */
public interface WithdrawalRequestObserver {
    /**
     * Called when a withdrawal request is created or updated
     * 
     * @param request The withdrawal request that was created or updated
     */
    void onWithdrawalRequest(WithdrawalRequest request);
}
