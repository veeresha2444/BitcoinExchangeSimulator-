package com.bankapp.factory;

import com.bankapp.model.Admin;
import com.bankapp.model.Role;
import com.bankapp.model.User;

import java.util.UUID;

/**
 * Factory class for creating different types of users
 * Implements the Factory design pattern
 */
public class UserFactory {
    /**
     * Create a new regular user
     * 
     * @param username The username
     * @param password The password (will be hashed before storage)
     * @param fullName The user's full name
     * @param email The user's email
     * @return The newly created user
     */
    public static User createRegularUser(String username, String password, String fullName, String email) {
        String userId = "user_" + UUID.randomUUID().toString();
        User user = new User(userId, username, password, fullName, email);
        user.setRole(Role.USER);
        return user;
    }
    
    /**
     * Create a new admin user
     * 
     * @param username The username
     * @param password The password (will be hashed before storage)
     * @param fullName The admin's full name
     * @param email The admin's email
     * @param employeeId The admin's employee ID
     * @param department The admin's department
     * @return The newly created admin
     */
    public static Admin createAdminUser(String username, String password, String fullName, 
                                        String email, String employeeId, String department) {
        String userId = "admin_" + UUID.randomUUID().toString();
        Admin admin = new Admin(userId, username, password, fullName, email, employeeId, department);
        admin.setRole(Role.ADMIN);
        
        // Add default permissions
        admin.addPermission("USER_MANAGEMENT");
        admin.addPermission("ACCOUNT_MANAGEMENT");
        admin.addPermission("TRANSACTION_MANAGEMENT");
        admin.addPermission("WITHDRAWAL_APPROVAL");
        
        return admin;
    }
    
    /**
     * Create a user instance based on the specified role
     * 
     * @param role The role of the user to create
     * @param username The username
     * @param password The password (will be hashed before storage)
     * @param fullName The user's full name
     * @param email The user's email
     * @return The newly created user
     */
    public static User createUser(Role role, String username, String password, String fullName, String email) {
        if (role == Role.ADMIN) {
            String employeeId = "EMP" + System.currentTimeMillis();
            String department = "Administration";
            return createAdminUser(username, password, fullName, email, employeeId, department);
        } else {
            return createRegularUser(username, password, fullName, email);
        }
    }
    
    /**
     * Create a demo user for testing purposes
     * 
     * @param isAdmin Whether to create an admin user
     * @return The newly created user
     */
    public static User createDemoUser(boolean isAdmin) {
        if (isAdmin) {
            return createAdminUser(
                "admin", 
                "admin123", 
                "Admin User", 
                "admin@example.com", 
                "EMP123456", 
                "IT Administration"
            );
        } else {
            return createRegularUser(
                "user", 
                "user123", 
                "Regular User", 
                "user@example.com"
            );
        }
    }
}
