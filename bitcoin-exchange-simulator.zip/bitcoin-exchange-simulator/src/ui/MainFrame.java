package ui;

import dao.DBConnection;
import dao.MarketEventLogDAO;
import dao.NotificationLogDAO;
import model.MarketEventLog;
import model.NotificationLog;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.List;

public class MainFrame extends JFrame {
    private MarketEventLogDAO marketDAO;
    private NotificationLogDAO notifDAO;

    // UI Components
    private JTable marketTable;
    private JTable notifTable;
    private DefaultTableModel marketModel;
    private DefaultTableModel notifModel;

    private JTextField eventTypeField, tradeIdField, statusField, oldPriceField, newPriceField;
    private JTextField notifTradeIdField, notifStatusField, changeIdField, sentToUserField, messageField;

    public MainFrame() {
        setTitle("Bitcoin Exchange - Administrator");
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        try {
            Connection conn = DBConnection.getConnection();
            marketDAO = new MarketEventLogDAO(conn);
            notifDAO = new NotificationLogDAO(conn);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }

        initComponents();
    }

    private void initComponents() {
        JTabbedPane tabs = new JTabbedPane();

        // Market Panel
        JPanel marketPanel = new JPanel(new BorderLayout());
        marketModel = new DefaultTableModel(new String[]{"ID", "Event Type", "Trade ID", "Status", "Old Price", "New Price", "Timestamp"}, 0);
        marketTable = new JTable(marketModel);
        marketPanel.add(new JScrollPane(marketTable), BorderLayout.CENTER);
        marketPanel.add(buildMarketForm(), BorderLayout.NORTH);
        marketPanel.add(buildMarketButtons(), BorderLayout.SOUTH);

        // Notification Panel
        JPanel notifPanel = new JPanel(new BorderLayout());
        notifModel = new DefaultTableModel(new String[]{"ID", "Trade ID", "Status", "Change ID", "User ID", "Message", "Timestamp"}, 0);
        notifTable = new JTable(notifModel);
        notifPanel.add(new JScrollPane(notifTable), BorderLayout.CENTER);
        notifPanel.add(buildNotifForm(), BorderLayout.NORTH);
        notifPanel.add(buildNotifButtons(), BorderLayout.SOUTH);

        // Add tabs
        tabs.add("Market Events", marketPanel);
        tabs.add("Notification Logs", notifPanel);
        add(tabs);

        loadMarketData();
        loadNotifData();
    }

    private JPanel buildMarketForm() {
        eventTypeField = new JTextField(10);
        tradeIdField = new JTextField(10);
        statusField = new JTextField(10);
        oldPriceField = new JTextField(10);
        newPriceField = new JTextField(10);

        JPanel panel = new JPanel(new GridLayout(2, 5, 5, 5));
        panel.add(new JLabel("Event Type"));
        panel.add(new JLabel("Trade ID"));
        panel.add(new JLabel("Status"));
        panel.add(new JLabel("Old Price"));
        panel.add(new JLabel("New Price"));

        panel.add(eventTypeField);
        panel.add(tradeIdField);
        panel.add(statusField);
        panel.add(oldPriceField);
        panel.add(newPriceField);
        return panel;
    }

    private JPanel buildMarketButtons() {
        JButton add = new JButton("Add");
        JButton update = new JButton("Update");
        JButton delete = new JButton("Delete");

        add.addActionListener(this::addMarket);
        update.addActionListener(this::updateMarket);
        delete.addActionListener(this::deleteMarket);

        JPanel panel = new JPanel();
        panel.add(add);
        panel.add(update);
        panel.add(delete);
        return panel;
    }

    private JPanel buildNotifForm() {
        notifTradeIdField = new JTextField(10);
        notifStatusField = new JTextField(10);
        changeIdField = new JTextField(5);
        sentToUserField = new JTextField(5);
        messageField = new JTextField(15);

        JPanel panel = new JPanel(new GridLayout(2, 5, 5, 5));
        panel.add(new JLabel("Trade ID"));
        panel.add(new JLabel("Status"));
        panel.add(new JLabel("Change ID"));
        panel.add(new JLabel("Sent To User ID"));
        panel.add(new JLabel("Message"));

        panel.add(notifTradeIdField);
        panel.add(notifStatusField);
        panel.add(changeIdField);
        panel.add(sentToUserField);
        panel.add(messageField);
        return panel;
    }

    private JPanel buildNotifButtons() {
        JButton add = new JButton("Add");
        JButton update = new JButton("Update");
        JButton delete = new JButton("Delete");

        add.addActionListener(this::addNotif);
        update.addActionListener(this::updateNotif);
        delete.addActionListener(this::deleteNotif);

        JPanel panel = new JPanel();
        panel.add(add);
        panel.add(update);
        panel.add(delete);
        return panel;
    }

    private void loadMarketData() {
        try {
            marketModel.setRowCount(0);
            for (MarketEventLog e : marketDAO.getAll()) {
                marketModel.addRow(new Object[]{
                        e.getId(), e.getEventType(), e.getTradeId(), e.getStatus(),
                        e.getOldPrice(), e.getNewPrice(), e.getTimestamp()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Load Market Events failed: " + e.getMessage());
        }
    }

    private void loadNotifData() {
        try {
            notifModel.setRowCount(0);
            for (NotificationLog n : notifDAO.getAll()) {
                notifModel.addRow(new Object[]{
                        n.getId(), n.getTradeId(), n.getStatus(), n.getChangeId(),
                        n.getSentToUserId(), n.getMessage(), n.getTimestamp()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Load Notifications failed: " + e.getMessage());
        }
    }

    private void addMarket(ActionEvent e) {
        try {
            MarketEventLog m = new MarketEventLog();
            m.setEventType(eventTypeField.getText());
            m.setTradeId(tradeIdField.getText());
            m.setStatus(statusField.getText());
            m.setOldPrice(Double.parseDouble(oldPriceField.getText()));
            m.setNewPrice(Double.parseDouble(newPriceField.getText()));
            m.setTimestamp(new Timestamp(System.currentTimeMillis()));
            marketDAO.insert(m);
            loadMarketData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Add Market failed: " + ex.getMessage());
        }
    }

    private void updateMarket(ActionEvent e) {
        int row = marketTable.getSelectedRow();
        if (row == -1) return;

        try {
            MarketEventLog m = new MarketEventLog();
            m.setId((int) marketModel.getValueAt(row, 0));
            m.setEventType(eventTypeField.getText());
            m.setTradeId(tradeIdField.getText());
            m.setStatus(statusField.getText());
            m.setOldPrice(Double.parseDouble(oldPriceField.getText()));
            m.setNewPrice(Double.parseDouble(newPriceField.getText()));
            m.setTimestamp(new Timestamp(System.currentTimeMillis()));
            marketDAO.update(m);
            loadMarketData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Update Market failed: " + ex.getMessage());
        }
    }

    private void deleteMarket(ActionEvent e) {
        int row = marketTable.getSelectedRow();
        if (row == -1) return;

        try {
            int id = (int) marketModel.getValueAt(row, 0);
            marketDAO.delete(id);
            loadMarketData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Delete Market failed: " + ex.getMessage());
        }
    }

    private void addNotif(ActionEvent e) {
        try {
            NotificationLog n = new NotificationLog();
            n.setTradeId(notifTradeIdField.getText());
            n.setStatus(notifStatusField.getText());
            n.setChangeId(Integer.parseInt(changeIdField.getText()));
            n.setSentToUserId(Integer.parseInt(sentToUserField.getText()));
            n.setMessage(messageField.getText());
            n.setTimestamp(new Timestamp(System.currentTimeMillis()));
            notifDAO.insert(n);
            loadNotifData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Add Notification failed: " + ex.getMessage());
        }
    }

    private void updateNotif(ActionEvent e) {
        int row = notifTable.getSelectedRow();
        if (row == -1) return;

        try {
            NotificationLog n = new NotificationLog();
            n.setId((int) notifModel.getValueAt(row, 0));
            n.setTradeId(notifTradeIdField.getText());
            n.setStatus(notifStatusField.getText());
            n.setChangeId(Integer.parseInt(changeIdField.getText()));
            n.setSentToUserId(Integer.parseInt(sentToUserField.getText()));
            n.setMessage(messageField.getText());
            n.setTimestamp(new Timestamp(System.currentTimeMillis()));
            notifDAO.update(n);
            loadNotifData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Update Notification failed: " + ex.getMessage());
        }
    }

    private void deleteNotif(ActionEvent e) {
        int row = notifTable.getSelectedRow();
        if (row == -1) return;

        try {
            int id = (int) notifModel.getValueAt(row, 0);
            notifDAO.delete(id);
            loadNotifData();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Delete Notification failed: " + ex.getMessage());
        }
    }
}
