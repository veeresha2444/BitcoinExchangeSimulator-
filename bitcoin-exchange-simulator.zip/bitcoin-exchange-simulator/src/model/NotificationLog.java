package model;

import java.sql.Timestamp;

public class NotificationLog {
    private int id;
    private String tradeId;
    private String status;
    private int changeId;
    private int sentToUserId;
    private String message;
    private Timestamp timestamp;

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTradeId() { return tradeId; }
    public void setTradeId(String tradeId) { this.tradeId = tradeId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public int getChangeId() { return changeId; }
    public void setChangeId(int changeId) { this.changeId = changeId; }

    public int getSentToUserId() { return sentToUserId; }
    public void setSentToUserId(int sentToUserId) { this.sentToUserId = sentToUserId; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public Timestamp getTimestamp() { return timestamp; }
    public void setTimestamp(Timestamp timestamp) { this.timestamp = timestamp; }
}
