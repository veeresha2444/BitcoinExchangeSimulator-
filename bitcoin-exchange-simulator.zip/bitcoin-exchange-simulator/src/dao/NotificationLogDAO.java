package dao;

import model.NotificationLog;
import java.sql.*;
import java.util.*;

public class NotificationLogDAO {
    private Connection conn;

    public NotificationLogDAO(Connection conn) {
        this.conn = conn;
    }

    public void insert(NotificationLog n) throws SQLException {
        String sql = "INSERT INTO notification_log (trade_id, status, change_id, sent_to_user_id, message, timestamp) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, n.getTradeId());
            ps.setString(2, n.getStatus());
            ps.setInt(3, n.getChangeId());
            ps.setInt(4, n.getSentToUserId());
            ps.setString(5, n.getMessage());
            ps.setTimestamp(6, n.getTimestamp());
            ps.executeUpdate();
        }
    }

    public void update(NotificationLog n) throws SQLException {
        String sql = "UPDATE notification_log SET trade_id=?, status=?, change_id=?, sent_to_user_id=?, message=?, timestamp=? WHERE id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, n.getTradeId());
            ps.setString(2, n.getStatus());
            ps.setInt(3, n.getChangeId());
            ps.setInt(4, n.getSentToUserId());
            ps.setString(5, n.getMessage());
            ps.setTimestamp(6, n.getTimestamp());
            ps.setInt(7, n.getId());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM notification_log WHERE id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<NotificationLog> getAll() throws SQLException {
        List<NotificationLog> list = new ArrayList<>();
        String sql = "SELECT * FROM notification_log";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                NotificationLog n = new NotificationLog();
                n.setId(rs.getInt("id"));
                n.setTradeId(rs.getString("trade_id"));
                n.setStatus(rs.getString("status"));
                n.setChangeId(rs.getInt("change_id"));
                n.setSentToUserId(rs.getInt("sent_to_user_id"));
                n.setMessage(rs.getString("message"));
                n.setTimestamp(rs.getTimestamp("timestamp"));
                list.add(n);
            }
        }
        return list;
    }
}
