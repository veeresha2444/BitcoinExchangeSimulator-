package dao;

import model.MarketEventLog;
import java.sql.*;
import java.util.*;

public class MarketEventLogDAO {
    private Connection conn;

    public MarketEventLogDAO(Connection conn) {
        this.conn = conn;
    }

    public void insert(MarketEventLog e) throws SQLException {
        String sql = "INSERT INTO market_event_log (event_type, trade_id, status, old_price, new_price, timestamp) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, e.getEventType());
            ps.setString(2, e.getTradeId());
            ps.setString(3, e.getStatus());
            ps.setObject(4, e.getOldPrice());
            ps.setObject(5, e.getNewPrice());
            ps.setTimestamp(6, e.getTimestamp());
            ps.executeUpdate();
        }
    }

    public void update(MarketEventLog e) throws SQLException {
        String sql = "UPDATE market_event_log SET event_type=?, trade_id=?, status=?, old_price=?, new_price=?, timestamp=? WHERE id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, e.getEventType());
            ps.setString(2, e.getTradeId());
            ps.setString(3, e.getStatus());
            ps.setObject(4, e.getOldPrice());
            ps.setObject(5, e.getNewPrice());
            ps.setTimestamp(6, e.getTimestamp());
            ps.setInt(7, e.getId());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM market_event_log WHERE id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<MarketEventLog> getAll() throws SQLException {
        List<MarketEventLog> list = new ArrayList<>();
        String sql = "SELECT * FROM market_event_log";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                MarketEventLog e = new MarketEventLog();
                e.setId(rs.getInt("id"));
                e.setEventType(rs.getString("event_type"));
                e.setTradeId(rs.getString("trade_id"));
                e.setStatus(rs.getString("status"));
                e.setOldPrice(rs.getDouble("old_price"));
                e.setNewPrice(rs.getDouble("new_price"));
                e.setTimestamp(rs.getTimestamp("timestamp"));
                list.add(e);
            }
        }
        return list;
    }
}
