javac -cp "lib\mysql-connector-j-8.0.33.jar" -d bin src\model\*.java src\dao\*.java src\ui\MainFrame.java



java -cp "bin;lib\mysql-connector-j-8.0.33.jar" Main