package com.example.bitcoinexchangesimulator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BitcoinExchangeSimulatorApplicationTests {

    @Test
    void contextLoads() {
    }

}
