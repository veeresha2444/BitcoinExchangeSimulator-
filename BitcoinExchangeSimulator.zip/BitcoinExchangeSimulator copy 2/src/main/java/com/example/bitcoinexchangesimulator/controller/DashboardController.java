package com.example.bitcoinexchangesimulator.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/dashboard")
public class DashboardController {

    @GetMapping
    public String showDashboard(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        // Check if the user has the "ROLE_ADMIN" authority
        boolean isAdmin = authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_ADMIN"));

        // Add attributes to be used in Thymeleaf template
        model.addAttribute("username", authentication.getName());
        model.addAttribute("isAdmin", isAdmin);  // ✅ Now Thymeleaf can use this

        model.addAttribute("message", isAdmin ? "Welcome to the Admin Dashboard!" : "Welcome to your User Dashboard!");

        return "dashboard";  // ✅ Loads dashboard.html
    }
}
