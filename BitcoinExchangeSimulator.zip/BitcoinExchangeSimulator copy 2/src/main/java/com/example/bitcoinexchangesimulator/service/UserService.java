package com.example.bitcoinexchangesimulator.service;

import com.example.bitcoinexchangesimulator.factory.UserFactory;
import com.example.bitcoinexchangesimulator.model.Role;
import com.example.bitcoinexchangesimulator.model.User;
import com.example.bitcoinexchangesimulator.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public User registerUser(String username, String password, Role role) {
        if (userRepository.findByUsername(username).isPresent()) {
            throw new RuntimeException("Username already exists!");
        }

        // 🔹 Use UserFactory to create User object
        String encodedPassword = passwordEncoder.encode(password);
        User user = UserFactory.createUser(username, encodedPassword, role);

        return userRepository.save(user);
    }

    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // 🔹 Forgot Password - Generate Temp Password
    public ResponseEntity<String> forgotPassword(String username) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            String tempPassword = UUID.randomUUID().toString().substring(0, 8); // Generate 8-char temp password
            user.setPassword(passwordEncoder.encode(tempPassword));
            userRepository.save(user);
            return ResponseEntity.ok("Temporary password: " + tempPassword); // Normally, send via email
        } else {
            return ResponseEntity.badRequest().body("User not found!");
        }
    }

    // 🔹 Reset Password - Validate Temp Password & Set New Password
    public ResponseEntity<String> resetPassword(String username, String tempPassword, String newPassword) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (passwordEncoder.matches(tempPassword, user.getPassword())) {
                user.setPassword(passwordEncoder.encode(newPassword));
                userRepository.save(user);
                return ResponseEntity.ok("Password successfully updated!");
            } else {
                return ResponseEntity.badRequest().body("Invalid temporary password!");
            }
        } else {
            return ResponseEntity.badRequest().body("User not found!");
        }
    }

    public ResponseEntity<String> updateProfile(String currentUsername, String newUsername) {
        Optional<User> userOpt = userRepository.findByUsername(currentUsername);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (userRepository.findByUsername(newUsername).isPresent()) {
                return ResponseEntity.badRequest().body("Username already taken!");
            }
            user.setUsername(newUsername);
            userRepository.save(user);
            return ResponseEntity.ok("Username updated successfully!");
        } else {
            return ResponseEntity.badRequest().body("User not found!");
        }
    }

    public ResponseEntity<String> changePassword(String username, String oldPassword, String newPassword) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (passwordEncoder.matches(oldPassword, user.getPassword())) {
                user.setPassword(passwordEncoder.encode(newPassword));
                userRepository.save(user);
                return ResponseEntity.ok("Password changed successfully!");
            } else {
                return ResponseEntity.badRequest().body("Incorrect old password!");
            }
        } else {
            return ResponseEntity.badRequest().body("User not found!");
        }
    }

}
