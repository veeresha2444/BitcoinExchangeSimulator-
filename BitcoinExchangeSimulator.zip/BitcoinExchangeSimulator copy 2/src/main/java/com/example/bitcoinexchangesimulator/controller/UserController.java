package com.example.bitcoinexchangesimulator.controller;

import com.example.bitcoinexchangesimulator.model.User;
import com.example.bitcoinexchangesimulator.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // 🔹 View User Profile
    @GetMapping("/profile")
    public ResponseEntity<User> viewProfile(Principal principal) {
        return userService.findByUsername(principal.getName())
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // 🔹 Update User Profile
    @PutMapping("/profile/update")
    public ResponseEntity<String> updateProfile(Principal principal, @RequestParam String newUsername) {
        return userService.updateProfile(principal.getName(), newUsername);
    }

    // 🔹 Change Password
    @PostMapping("/profile/change-password")
    public ResponseEntity<String> changePassword(Principal principal,
                                                 @RequestParam String oldPassword,
                                                 @RequestParam String newPassword) {
        return userService.changePassword(principal.getName(), oldPassword, newPassword);
    }
}
