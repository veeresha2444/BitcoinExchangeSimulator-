//package com.example.bitcoinexchangesimulator.controller;
//
//import com.example.bitcoinexchangesimulator.model.User;
//import com.example.bitcoinexchangesimulator.repository.UserRepository;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.Optional;
//
//@Controller
//@RequestMapping("/profile")
//public class ProfileController {
//
//    private final UserRepository userRepository;
//
//    // ✅ Constructor Injection
//    public ProfileController(UserRepository userRepository) {
//        this.userRepository = userRepository;
//    }
//
//    @GetMapping
//    public String getProfile(Model model) {
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        String email = authentication.getName();
//        System.out.println("🔍 Authenticated user email: " + email);
//
//        Optional<User> userOpt = userRepository.findByEmail(email);
//
//        if (userOpt.isPresent()) {
//            User user = userOpt.get();
//            System.out.println("✅ User found: " + user.getName());
//            model.addAttribute("user", user);
//
//            // 🛑 **Only fetch all users if the logged-in user is an Admin**
//            if (user.getRole().equals("ADMIN")) {
//                System.out.println("🔹 User is an ADMIN - Fetching all users");
//                model.addAttribute("users", userRepository.findAll());
//            }
//
//            return "profile";
//        } else {
//            System.out.println("❌ User not found in database!");
//            return "error";
//        }
//    }
//
//    @PostMapping("/update")
//    public String updateProfile(@RequestParam String name, Model model) {
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        String email = authentication.getName();
//        Optional<User> userOpt = userRepository.findByEmail(email);
//
//        if (userOpt.isPresent()) {
//            User user = userOpt.get();
//            user.setName(name);
//            userRepository.save(user);
//            model.addAttribute("user", user);
//            model.addAttribute("message", "Profile updated successfully!");
//            return "profile";  // ✅ Show updated profile page
//        } else {
//            model.addAttribute("error", "User not found!");
//            return "error";
//        }
//    }
//}
package com.example.bitcoinexchangesimulator.controller;

import com.example.bitcoinexchangesimulator.model.User;
import com.example.bitcoinexchangesimulator.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/profile")
public class ProfileController {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public ProfileController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping
    public String getProfile(Model model, @RequestParam(value = "message", required = false) String message) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        Optional<User> userOpt = userRepository.findByEmail(email);

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            model.addAttribute("user", user);

            if (message != null) model.addAttribute("message", message);
            return "profile";
        } else {
            model.addAttribute("error", "User not found!");
            return "error";
        }
    }

    @PostMapping("/update")
    public String updateProfile(
            @RequestParam String name,
            @RequestParam String username,
            @RequestParam String oldPassword,
            @RequestParam String newPassword,
            Model model
    ) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        Optional<User> userOpt = userRepository.findByEmail(email);

        if (userOpt.isPresent()) {
            User user = userOpt.get();

            // 🔐 Password check with BCrypt
            if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
                model.addAttribute("error", "Old password is incorrect!");
                model.addAttribute("user", user);
                return "profile";
            }

            // ✅ Update fields
            user.setName(name);
            user.setUsername(username);
            user.setPassword(passwordEncoder.encode(newPassword));
            userRepository.save(user);

            return "redirect:/profile?message=Profile updated successfully!";
        } else {
            model.addAttribute("error", "User not found!");
            return "error";
        }
    }
}

