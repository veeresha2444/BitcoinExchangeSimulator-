package com.example.bitcoinexchangesimulator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BitcoinExchangeSimulatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(BitcoinExchangeSimulatorApplication.class, args);
    }

}
