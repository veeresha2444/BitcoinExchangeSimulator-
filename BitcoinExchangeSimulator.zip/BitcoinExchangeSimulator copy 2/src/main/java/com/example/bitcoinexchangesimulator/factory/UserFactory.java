package com.example.bitcoinexchangesimulator.factory;

import com.example.bitcoinexchangesimulator.model.Role;
import com.example.bitcoinexchangesimulator.model.User;
public class UserFactory {
    public static User createUser(String username, String password, Role role) {
        User user = new User();
        user.setUsername(username);
        user.setPassword(password); // Password is already encoded in service
        user.setRole(role);
        return user;
    }
}
