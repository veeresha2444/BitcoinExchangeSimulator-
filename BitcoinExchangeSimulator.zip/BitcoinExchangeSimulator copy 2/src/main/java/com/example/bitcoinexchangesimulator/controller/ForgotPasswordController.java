package com.example.bitcoinexchangesimulator.controller;

import com.example.bitcoinexchangesimulator.model.User;
import com.example.bitcoinexchangesimulator.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Controller
@RequestMapping("/forgot_password")
public class ForgotPasswordController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public ForgotPasswordController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping
    public String showForgotPasswordForm() {
        return "forgot_password"; // Create forgot-password.html
    }

    @PostMapping
    public String processForgotPassword(@RequestParam String email, Model model) {
        Optional<User> userOptional = userRepository.findByEmail(email);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            String token = UUID.randomUUID().toString();
            user.setResetToken(token);
            user.setTokenExpiry(LocalDateTime.now().plusMinutes(15)); // Token valid for 15 minutes
            userRepository.save(user);

            // Debugging statement
            System.out.println("Generated Reset Token: " + token);

            // Generate reset link
            String resetLink = "http://localhost:8080/forgot_password/reset?token=" + token;
            System.out.println("Generated Reset Link: " + resetLink); // Debugging
            model.addAttribute("resetLink", resetLink);
            model.addAttribute("message", "Click the link below to reset your password.");
        } else {
            model.addAttribute("message", "❌ Email not found!");
        }
        return "forgot_password";
    }


    @GetMapping("/reset")
    public String showResetPasswordForm(@RequestParam String token, Model model) {
        System.out.println("Received reset request with token: " + token);

        Optional<User> userOptional = userRepository.findByResetToken(token);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            System.out.println("Token found for user: " + user.getEmail());
            System.out.println("Token Expiry: " + user.getTokenExpiry());
            System.out.println("Current Time: " + LocalDateTime.now());

            if (user.getTokenExpiry().isAfter(LocalDateTime.now())) {
                model.addAttribute("token", token);
                return "reset_password";
            }
            System.out.println("Token Expired!");
        } else {
            System.out.println("Invalid Token!");
        }

        model.addAttribute("message", "❌ Invalid or expired token!");
        return "forgot_password";
    }

    @PostMapping("/reset")
    public String processResetPassword(@RequestParam String token,
                                       @RequestParam String newPassword,
                                       Model model) {
        System.out.println("Processing reset for token: " + token);

        Optional<User> userOptional = userRepository.findByResetToken(token);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            System.out.println("Resetting password for: " + user.getEmail());

            if (user.getTokenExpiry().isAfter(LocalDateTime.now())) {
                user.setPassword(passwordEncoder.encode(newPassword)); // Hash password
                user.setResetToken(null); // Clear token
                user.setTokenExpiry(null);
                userRepository.save(user);

                System.out.println("✅ Password reset successful for: " + user.getEmail());

                model.addAttribute("message", "✅ Password reset successful! Please log in.");
                return "login"; // Instead of "redirect:/login"
            }
            System.out.println("Token Expired!");
        } else {
            System.out.println("Invalid Token!");
        }

        model.addAttribute("message", "❌ Invalid or expired token!");
        return "forgot_password";
    }

}
