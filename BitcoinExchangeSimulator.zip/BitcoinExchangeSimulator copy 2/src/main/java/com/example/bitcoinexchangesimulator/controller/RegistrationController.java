package com.example.bitcoinexchangesimulator.controller;

import com.example.bitcoinexchangesimulator.model.User;
import com.example.bitcoinexchangesimulator.model.Role;
import com.example.bitcoinexchangesimulator.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/register")
public class RegistrationController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public RegistrationController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User()); // Ensure empty user object for form binding
        return "register"; // Show register.html
    }

    @PostMapping
    public String processRegistration(@ModelAttribute User user, Model model) {
        // Check if email already exists
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            model.addAttribute("message", "❌ Email already exists!");
            return "register";
        }

        // Check if username already exists
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            model.addAttribute("message", "❌ Username already exists!");
            return "register";
        }

        // Ensure fields are not empty
        if (user.getName().isEmpty() || user.getEmail().isEmpty() ||
                user.getUsername().isEmpty() || user.getPassword().isEmpty()) {
            model.addAttribute("message", "❌ All fields are required!");
            return "register";
        }

        // Hash the password before saving
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole(Role.USER); // Default role

        // Save user
        userRepository.save(user);

        model.addAttribute("message", "✅ Registration successful! Please log in.");
        return "redirect:/login"; // Redirect to login page
    }
}
