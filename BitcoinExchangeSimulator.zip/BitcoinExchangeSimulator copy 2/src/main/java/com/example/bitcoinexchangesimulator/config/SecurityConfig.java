package com.example.bitcoinexchangesimulator.config;

import com.example.bitcoinexchangesimulator.service.CustomUserDetailsService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final CustomUserDetailsService customUserDetailsService;

    public SecurityConfig(CustomUserDetailsService customUserDetailsService) {
        this.customUserDetailsService = customUserDetailsService;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())  // Disabling CSRF if necessary for certain endpoints
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/h2-console/**", "/register", "/login", "/api/status", "/profile", "/error").permitAll()
                        .requestMatchers("/forgot_password", "/forgot_password/**", "/reset_password", "/reset_password/**").permitAll()
//                        .requestMatchers("/admin/admin-key-prompt", "/admin/admin-registration", "/admin/admin-error").permitAll()  // Allow public access to these
//                        .requestMatchers("/admin/verify-admin-key").permitAll()
                        .requestMatchers("/admin/**").hasRole("ADMIN")  // Only allow admin for other routes
                        .anyRequest().authenticated()  // Require authentication for other routes
                )
                .headers(headers -> headers.frameOptions(frameOptions -> frameOptions.disable()))  // Allow H2 console frames
                .formLogin(login -> login
                        .loginPage("/login")
                        .usernameParameter("email")
                        .defaultSuccessUrl("/dashboard", true)
                        .permitAll()  // Allow public access to login page
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login")
                        .permitAll()  // Allow public access to logout page
                );

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }
}
