package com.example.bitcoinexchangesimulator.model;

public enum Role {
    ADMIN, USER
}

