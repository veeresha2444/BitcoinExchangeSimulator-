package com.example.bitcoinexchangesimulator.utils;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordCheck {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        System.out.println(encoder.matches("password123", "$2a$10$T5/f9xPb8IO5A2X.QXyJ6OvHPZ4ZCwH1HkIoRf9kKa9mF5D6V5a2m"));
    }
}
