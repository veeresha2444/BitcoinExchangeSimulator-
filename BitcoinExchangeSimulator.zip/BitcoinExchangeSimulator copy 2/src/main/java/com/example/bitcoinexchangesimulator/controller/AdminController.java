package com.example.bitcoinexchangesimulator.controller;

import com.example.bitcoinexchangesimulator.model.User;
import com.example.bitcoinexchangesimulator.model.Role;
import com.example.bitcoinexchangesimulator.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

//    @Value("${admin.secret-key}")  // Load the secret key from application.properties
//    private String secretKey;

    // Existing Admin Dashboard
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/dashboard")
    public String showAdminDashboard() {
        return "admin_dashboard";
    }

    // Existing list users functionality
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/users")
    public String listUsers(Model model) {
        List<User> users = userRepository.findAll();
        model.addAttribute("users", users);
        return "user_listing";
    }

    // Existing delete user functionality
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/users/{id}")
    public String deleteUser(@PathVariable Long id) {
        userRepository.deleteById(id);
        return "redirect:/admin/users";
    }

    // Existing assign role functionality
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/users/{id}/assign-role")
    public String assignRole(@PathVariable Long id, @RequestParam String role) {
        Optional<User> userOpt = userRepository.findById(id);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            try {
                user.setRole(Role.valueOf(role.toUpperCase()));
                userRepository.save(user);
                return "redirect:/admin/users";
            } catch (IllegalArgumentException e) {
                return "Invalid role! Allowed values: USER, ADMIN";
            }
        } else {
            return "User not found!";
        }
    }


    // Handle the actual admin registration
//    @PostMapping("/register-admin")
//    public String registerAdmin(@RequestParam String username, @RequestParam String email,
//                                @RequestParam String password, Model model) {
//
//        // Check if the email or username already exists
//        if (userRepository.findByEmail(email).isPresent() ||
//                userRepository.findByUsername(username).isPresent()) {
//            model.addAttribute("error", "Email or Username already exists!");
//            return "admin-registration";  // Show form again with error message
//        }
//
//        // Create the admin user
//        User user = new User();
//        user.setUsername(username);
//        user.setEmail(email);
//        user.setPassword(passwordEncoder.encode(password));  // Encrypt the password
//        user.setRole(Role.ADMIN);
//
//        userRepository.save(user);
//        return "redirect:/admin/users";  // Redirect to user listing after successful registration
//    }
    // Handle the actual admin registration
//    @PostMapping("/register-admin")
//    public String registerAdmin(@RequestParam String username, @RequestParam String email,
//                                @RequestParam String password, Model model) {
//
//        // Check if the email or username already exists
//        if (userRepository.findByEmail(email).isPresent() ||
//                userRepository.findByUsername(username).isPresent()) {
//            model.addAttribute("error", "Email or Username already exists!");
//            return "admin-registration";  // Show form again with error message
//        }
//
//        // Create the admin user
//        User user = new User();
//        user.setUsername(username);
//        user.setEmail(email);
//        user.setPassword(passwordEncoder.encode(password));  // Encrypt the password
//        user.setRole(Role.ADMIN);  // Set the role as admin
//
//        // Log user details to ensure data is correct before saving
//        System.out.println("Registering admin: Username = " + username + ", Email = " + email);
//
//        // Save the admin user to the database
//        try {
//            userRepository.save(user);
//            System.out.println("Admin registered successfully");
//        } catch (Exception e) {
//            System.out.println("Error saving admin: " + e.getMessage());
//        }
//
//        // After successful registration, redirect to the login page
//        return "redirect:/login";  // Redirect to login page after successful registration
//    }



    // Existing user creation functionality
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/users/new")
    public String showUserForm(Model model) {
        model.addAttribute("user", new User());
        return "user_form";  // This is the name of the HTML file you’ll create for user creation
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/users")
    public String createUser(@RequestParam String name,
                             @RequestParam String username,
                             @RequestParam String email,
                             @RequestParam String password,
                             @RequestParam String role,
                             Model model) {

        // Check if email or username already exists
        if (userRepository.findByEmail(email).isPresent() ||
                userRepository.findByUsername(username).isPresent()) {
            model.addAttribute("error", "Email or Username already exists!");
            return "user_form"; // Show form again with error
        }

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setUsername(username); // Now reading username from the form
        user.setPassword(passwordEncoder.encode(password));
        user.setRole(Role.valueOf(role.toUpperCase()));

        userRepository.save(user);
        return "redirect:/admin/users";  // Redirect to users list after successful creation
    }
}
